const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const WebSocket = require('ws');

const PORT = process.env.PORT || 8080;
const MAX_HISTORY = 80;
const MAX_IMAGE_BYTES = 6 * 1024 * 1024; // 单张上限 6MB

// 内存消息历史（重启即清空）；图片落盘到 uploads/
const history = [];
const clients = new Map(); // ws -> {name, id}
let seq = 0;

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const MIME_EXT = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/webp': 'webp',
  'image/gif': 'gif'
};

function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(obj));
}

function baseUrl(req) {
  const proto = req.headers['x-forwarded-proto'] || 'http';
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  return proto + '://' + host;
}

/** 处理图片上传：POST /upload  body = 原始二进制，Content-Type 为图片类型 */
function handleUpload(req, res) {
  const ctype = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
  const ext = MIME_EXT[ctype];
  if (!ext) {
    json(res, 415, { ok: false, error: '只支持 PNG / JPG / WEBP / GIF' });
    req.resume();
    return;
  }

  const chunks = [];
  let size = 0;
  let aborted = false;

  req.on('data', c => {
    if (aborted) return;
    size += c.length;
    if (size > MAX_IMAGE_BYTES) {
      aborted = true;
      json(res, 413, { ok: false, error: '图片超过 6MB' });
      req.destroy();
      return;
    }
    chunks.push(c);
  });

  req.on('end', () => {
    if (aborted) return;
    const buf = Buffer.concat(chunks);
    if (buf.length === 0) {
      json(res, 400, { ok: false, error: '空文件' });
      return;
    }
    // 校验文件头，防止伪装
    const isPng = buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
    const isJpg = buf[0] === 0xff && buf[1] === 0xd8;
    const isGif = buf.slice(0, 3).toString('ascii') === 'GIF';
    const isWebp = buf.slice(0, 4).toString('ascii') === 'RIFF' &&
      buf.slice(8, 12).toString('ascii') === 'WEBP';
    if (!isPng && !isJpg && !isGif && !isWebp) {
      json(res, 400, { ok: false, error: '不是有效的图片文件' });
      return;
    }

    const name = crypto.randomBytes(12).toString('hex') + '.' + ext;
    fs.writeFile(UPLOAD_DIR + '/' + name, buf, err => {
      if (err) {
        json(res, 500, { ok: false, error: '保存失败' });
        return;
      }
      json(res, 200, {
        ok: true,
        // 返回相对路径，客户端用自己的服务地址拼接，避免反代主机名不一致
        path: '/img/' + name,
        url: baseUrl(req) + '/img/' + name,
        size: buf.length
      });
    });
  });

  req.on('error', () => {
    if (!aborted) json(res, 500, { ok: false, error: '传输中断' });
  });
}

const server = http.createServer((req, res) => {
  const url = (req.url || '').split('?')[0];

  if (url === '/health') {
    json(res, 200, { ok: true, online: clients.size, messages: history.length });
    return;
  }

  if (url === '/upload' && req.method === 'POST') {
    handleUpload(req, res);
    return;
  }

  if (url.startsWith('/img/')) {
    const name = path.basename(url.slice(5));
    const file = path.join(UPLOAD_DIR, name);
    if (!fs.existsSync(file)) {
      res.writeHead(404);
      res.end('not found');
      return;
    }
    const ext = path.extname(name).slice(1).toLowerCase();
    const type = ext === 'png' ? 'image/png'
      : ext === 'gif' ? 'image/gif'
      : ext === 'webp' ? 'image/webp'
      : 'image/jpeg';
    res.writeHead(200, {
      'Content-Type': type,
      'Cache-Control': 'public, max-age=86400'
    });
    fs.createReadStream(file).pipe(res);
    return;
  }

  res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('XY Shield chat server running');
});

const wss = new WebSocket.Server({ server, path: '/ws' });

function broadcast(obj) {
  const data = JSON.stringify(obj);
  for (const ws of clients.keys()) {
    if (ws.readyState === WebSocket.OPEN) ws.send(data);
  }
}

function onlineList() {
  return Array.from(clients.values()).map(c => c.name);
}

wss.on('connection', ws => {
  const id = ++seq;
  const name = '用户' + String(1000 + id);
  clients.set(ws, { name, id });

  ws.send(JSON.stringify({
    type: 'welcome',
    id,
    name,
    online: clients.size,
    history: history.slice(-MAX_HISTORY)
  }));

  broadcast({ type: 'online', online: clients.size, users: onlineList() });

  ws.on('message', raw => {
    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch (e) {
      return;
    }
    if (msg.type !== 'chat') return;

    const me = clients.get(ws);
    if (!me) return;

    const text = String(msg.text || '').trim().slice(0, 500);
    const image = typeof msg.image === 'string' ? msg.image.trim() : '';

    // 必须有文字或图片
    if (!text && !image) return;

    // 图片必须是本站上传的 /img/ 路径，防止注入外链
    let safeImage = '';
    if (image) {
      try {
        const u = new URL(image);
        if (u.pathname.startsWith('/img/')) safeImage = image;
      } catch (e) {
        if (image.startsWith('/img/')) safeImage = image;
      }
    }

    const item = {
      type: 'chat',
      name: me.name,
      text,
      image: safeImage || null,
      time: Date.now(),
      self: false
    };
    history.push(item);
    if (history.length > MAX_HISTORY) history.shift();

    broadcast(item);
  });

  ws.on('close', () => {
    clients.delete(ws);
    broadcast({ type: 'online', online: clients.size, users: onlineList() });
  });

  ws.on('error', () => {
    clients.delete(ws);
  });
});

server.listen(PORT, '0.0.0.0', () => {  console.log('XY chat server listening on ' + PORT);
});
