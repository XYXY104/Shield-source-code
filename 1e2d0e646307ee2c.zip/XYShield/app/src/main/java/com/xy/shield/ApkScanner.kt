package com.xy.shield

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.util.zip.ZipFile

/**
 * APK 拆包分析引擎。
 *
 * 流程：
 *  1. 把用户选的 APK 复制到私有目录
 *  2. 用 ZipFile 解包，遍历所有条目
 *  3. 图片全部解出到 cacheDir/apk_scan/images/，供用户在界面上查看
 *  4. 检测「硬编码密码 / 敏感凭证」
 *  5. 检测「恐怖图片」：文件名关键词 + 超大且接近全黑
 *  6. 两类特征同时命中 → 判定为病毒
 */
object ApkScanner {

    data class Finding(
        val title: String,
        val detail: String,
        val severity: Int   // 0 低 1 中 2 高
    )

    /** 解出来的一张图片 */
    data class ScannedImage(
        val entryName: String,      // APK 内路径
        val file: File,             // 解出的本地文件
        val sizeBytes: Long,
        val width: Int,
        val height: Int,
        val horror: Boolean,        // 是否命中恐怖判定
        val horrorReason: String    // 命中原因，空则未命中
    )

    data class Result(
        val fileName: String,
        val sizeBytes: Long,
        val fileCount: Int,
        val imageCount: Int,
        val dexCount: Int,
        val hasHardcodedPassword: Boolean,
        val hasHorrorImage: Boolean,
        val isVirus: Boolean,
        val findings: List<Finding>,
        val passwordHits: List<String>,
        val horrorHits: List<String>,
        val images: List<ScannedImage>
    )

    /** 恐怖/血腥类图片名关键词 */
    private val HORROR_KEYS = listOf(
        "horror", "scare", "scary", "ghost", "blood", "bloody", "dead",
        "death", "corpse", "skull", "zombie", "demon", "devil", "creepy",
        "jump", "terror", "fear", "nightmare", "gore", "hell",
        "鬼", "恐怖", "血", "尸", "骷髅", "惊悚", "丧"
    )

    private val TEXT_EXT = listOf(".xml", ".json", ".txt", ".properties", ".cfg", ".js", ".smali")

    /** 单次最多解出多少张图，避免超大 APK 撑爆缓存 */
    private const val MAX_EXTRACT = 400

    fun scan(ctx: Context, uri: Uri, fileName: String, onProgress: (String, Int) -> Unit): Result {
        val work = File(ctx.cacheDir, "apk_scan").apply { mkdirs() }
        val local = File(work, "target.apk")
        if (local.exists()) local.delete()

        // 清空上一次的图片
        val imgDir = File(work, "images").apply { mkdirs() }
        imgDir.listFiles()?.forEach { it.delete() }

        onProgress("正在读取安装包…", 4)
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            local.outputStream().use { out -> input.copyTo(out) }
        } ?: throw IllegalStateException("无法读取文件")

        val sizeBytes = local.length()
        val findings = mutableListOf<Finding>()
        val pwdHits = mutableListOf<String>()
        val horrorHits = mutableListOf<String>()
        val images = mutableListOf<ScannedImage>()
        var fileCount = 0
        var imageCount = 0
        var dexCount = 0

        ZipFile(local).use { zip ->
            val entries = zip.entries().toList()
            val total = entries.size.coerceAtLeast(1)

            entries.forEachIndexed { idx, e ->
                if (e.isDirectory) return@forEachIndexed
                fileCount++
                val name = e.name.lowercase()

                if (idx % 40 == 0) {
                    onProgress("正在拆解 ${e.name.takeLast(26)}", 8 + idx * 82 / total)
                }

                when {
                    name.endsWith(".dex") -> dexCount++

                    isImage(name) -> {
                        imageCount++
                        if (images.size < MAX_EXTRACT && e.size > 0) {
                            val scanned = extractImage(zip, e, imgDir)
                            if (scanned != null) images.add(scanned)
                        }
                    }

                    TEXT_EXT.any { name.endsWith(it) } -> {
                        if (e.size in 1..2_000_000L) {
                            val hits = runCatching {
                                zip.getInputStream(e).use { ins ->
                                    matchPassword(ins.readBytes().toString(Charsets.UTF_8))
                                }
                            }.getOrDefault(emptyList())
                            hits.take(3).forEach { pwdHits.add("${e.name} → $it") }
                        }
                    }
                }
            }
        }

        onProgress("正在分析风险…", 95)

        // 命中恐怖判定的图片，补进命中清单
        images.filter { it.horror }.forEach { horrorHits.add("${it.entryName}（${it.horrorReason}）") }

        val hasPwd = pwdHits.isNotEmpty()
        val hasHorror = horrorHits.isNotEmpty()

        if (hasHorror) {
            findings.add(Finding(
                "检测到恐怖图片",
                "共 ${horrorHits.size} 处可疑图片资源，可在下方逐张查看",
                2))
        }
        if (hasPwd) {
            findings.add(Finding(
                "检测到硬编码密码",
                "共 ${pwdHits.size} 处明文凭证，可能导致账号或数据泄露",
                2))
        }
        if (dexCount == 0) {
            findings.add(Finding("无代码段", "包内没有任何 dex 文件，可能被二次打包或损坏", 1))
        }
        if (fileCount > 8000) {
            findings.add(Finding("文件数量异常", "共 $fileCount 个文件，可能包含隐藏载荷", 1))
        }

        val isVirus = hasHorror && hasPwd

        onProgress("分析完成", 100)
        runCatching { local.delete() }

        return Result(
            fileName = fileName,
            sizeBytes = sizeBytes,
            fileCount = fileCount,
            imageCount = imageCount,
            dexCount = dexCount,
            hasHardcodedPassword = hasPwd,
            hasHorrorImage = hasHorror,
            isVirus = isVirus,
            findings = findings,
            passwordHits = pwdHits.distinct().take(20),
            horrorHits = horrorHits.distinct().take(20),
            images = images
        )
    }

    /** 把一张图片从 zip 解到本地，并顺便做恐怖判定 */
    private fun extractImage(zip: ZipFile, e: java.util.zip.ZipEntry, dir: File): ScannedImage? {
        val safeName = e.name.replace('/', '_').replace('\\', '_')
        val out = File(dir, safeName)

        val ok = runCatching {
            zip.getInputStream(e).use { ins ->
                out.outputStream().use { ins.copyTo(it) }
            }
        }.isSuccess
        if (!ok || !out.exists() || out.length() == 0L) {
            runCatching { out.delete() }
            return null
        }

        // 读取尺寸
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(out.absolutePath, opts)
        val w = opts.outWidth
        val h = opts.outHeight

        // 解不出来的（不是真图片）删掉
        if (w <= 0 || h <= 0) {
            runCatching { out.delete() }
            return null
        }

        // 恐怖判定 1：文件名关键词
        val lower = e.name.lowercase()
        val keyHit = HORROR_KEYS.firstOrNull { lower.contains(it) }
        if (keyHit != null) {
            return ScannedImage(e.name, out, out.length(), w, h, true, "文件名含「$keyHit」")
        }

        // 恐怖判定 2：超大且接近全黑（藏图常用手法）
        if (out.length() > 3_000_000L) {
            val dark = runCatching {
                val sample = BitmapFactory.decodeFile(out.absolutePath,
                    BitmapFactory.Options().apply { inSampleSize = 8 })
                    ?: return@runCatching false
                val avg = averageBrightness(sample)
                sample.recycle()
                avg < 28f
            }.getOrDefault(false)
            if (dark) {
                return ScannedImage(e.name, out, out.length(), w, h, true, "超大且接近全黑，疑似隐藏图片")
            }
        }

        return ScannedImage(e.name, out, out.length(), w, h, false, "")
    }

    private fun isImage(n: String) =
        n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") ||
        n.endsWith(".webp") || n.endsWith(".gif") || n.endsWith(".bmp")

    /** 在文本里匹配密码赋值：兼容 key = "xxx"、key: "xxx"、<string name="key">xxx</string> */
    private fun matchPassword(text: String): List<String> {
        val out = mutableListOf<String>()

        val reAssign = Regex(
            """(?i)([\w.\-]*(?:password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key|secret[_-]?key|private[_-]?key|credential)[\w.\-]*)\s*[=:]\s*["']([^"']{4,64})["']"""
        )
        for (m in reAssign.findAll(text)) {
            val key = m.groupValues[1]
            val value = m.groupValues[2]
            if (!isPlaceholder(value)) out.add("$key = \"$value\"")
            if (out.size >= 6) return out
        }

        val reXml = Regex(
            """(?is)<string\s+name\s*=\s*["']([^"']*(?:password|passwd|pwd|secret|token|api[_-]?key|key|credential)[^"']*)["'][^>]*>(.*?)</string>"""
        )
        for (m in reXml.findAll(text)) {
            val key = m.groupValues[1]
            var value = m.groupValues[2].trim()
            value = value.replace("&quot;", "\"").replace("\n", " ").trim()
            if (value.length < 4 || value.length > 64) continue
            if (isPlaceholder(value)) continue
            out.add("$key = \"$value\"")
            if (out.size >= 6) return out
        }

        return out
    }

    private fun isPlaceholder(value: String): Boolean {
        val v = value.trim()
        if (v.isEmpty()) return true
        val lower = v.lowercase()
        if (lower in listOf("null", "none", "true", "false", "0", "password", "xxx",
                "your_password", "changeme", "")) return true
        if (v.startsWith("@string/") || v.startsWith("@android:")) return true
        if (v.contains("${'$'}")) return true
        if (v.all { it == '_' || it == '*' || it == '.' }) return true
        return false
    }

    private fun averageBrightness(bmp: Bitmap): Float {
        var sum = 0L
        var count = 0
        val stepX = (bmp.width / 24).coerceAtLeast(1)
        val stepY = (bmp.height / 24).coerceAtLeast(1)
        var y = 0
        while (y < bmp.height) {
            var x = 0
            while (x < bmp.width) {
                val p = bmp.getPixel(x, y)
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                sum += (r * 299 + g * 587 + b * 114) / 1000
                count++
                x += stepX
            }
            y += stepY
        }
        return if (count == 0) 255f else sum.toFloat() / count
    }
}
