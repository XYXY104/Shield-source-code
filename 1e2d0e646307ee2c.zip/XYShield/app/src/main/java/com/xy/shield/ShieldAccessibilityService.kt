package com.xy.shield

import android.accessibilityservice.AccessibilityService
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.view.accessibility.AccessibilityEvent

/**
 * 无障碍服务：实时追踪当前前台应用。
 *
 * 双通道设计（关键修复）：
 *  1. 事件通道：监听 TYPE_WINDOW_STATE_CHANGED 更新缓存
 *  2. 查询通道：UsageStatsManager 实时查前台应用
 *
 * 只靠事件通道会出现：停在同一个应用页面摇一摇，没有窗口切换事件，
 * currentPkg 还是 null 或旧值 → 弹窗显示「未检测到前台应用」、卸载按钮无效。
 */
class ShieldAccessibilityService : AccessibilityService() {

    companion object {
        @JvmStatic
        var isRunning = false
            private set

        @JvmStatic
        var currentPkg: String? = null
            private set

        /** 最近一次事件时间戳 */
        private var lastEventAt = 0L

        /**
         * 取当前真正在前台的应用包名。
         * 先用 UsageStats 实时查（最准），拿不到再用事件缓存。
         */
        @JvmStatic
        fun getCurrentForeground(ctx: Context): String? {
            val fromUsage = queryForegroundByUsage(ctx)
            val fromEvent = currentPkg

            // 两者都有：以 UsageStats 结果为准，但过滤掉我们自己和桌面
            if (fromUsage != null && !isNoise(fromUsage, ctx)) return fromUsage

            if (fromEvent != null && !isNoise(fromEvent, ctx)) return fromEvent

            // 事件在 90 秒内更新过就用它
            if (System.currentTimeMillis() - lastEventAt < 90_000L) return fromEvent
            return null
        }

        /** 过滤自身 / 桌面 / 系统 UI 这类无意义结果 */
        private fun isNoise(pkg: String, ctx: Context): Boolean {
            if (pkg == ctx.packageName) return true
            if (pkg == "android") return true
            if (pkg == "com.android.systemui") return true
            if (pkg.startsWith("com.android.systemui")) return true
            return Launchers.isLauncher(ctx, pkg)
        }

        /**
         * 用 UsageStatsManager 查最近 10 秒内最后活跃的、属于某个应用的包。
         * 需要「使用情况访问权限」，没有权限会返回空，此时退回事件缓存。
         */
        private fun queryForegroundByUsage(ctx: Context): String? {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return null
            return try {
                val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                    ?: return null
                val now = System.currentTimeMillis()
                val stats = usm.queryUsageStats(
                    UsageStatsManager.INTERVAL_DAILY, now - 60_000L, now + 1_000L
                ) ?: return null
                if (stats.isEmpty()) return null

                // 取最近一次活跃且确实属于应用（有启动入口）的包
                val sorted = stats.sortedByDescending { it.lastTimeUsed }
                for (s in sorted) {
                    val pkg = s.packageName ?: continue
                    if (pkg == ctx.packageName) continue
                    if (pkg == "android" || pkg.startsWith("com.android.systemui")) continue
                    if (Launchers.isLauncher(ctx, pkg)) continue
                    // 必须是有界面的应用
                    if (ctx.packageManager.getLaunchIntentForPackage(pkg) == null) continue
                    return pkg
                }
                null
            } catch (e: Exception) {
                null
            }
        }

        /** 弹窗内调用：把前台应用写回缓存并返回 */
        @JvmStatic
        fun refresh(ctx: Context): String? {
            val p = getCurrentForeground(ctx)
            if (p != null) currentPkg = p
            return p
        }
    }

    private val appStack = ArrayDeque<String>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true
        Launchers.warmUp(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        currentPkg = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val type = event?.eventType ?: return
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return           // 自己
        if (pkg == "android") return             // 系统对话框

        // 桌面：清空，视为没有前台应用
        if (Launchers.isLauncher(this, pkg)) {
            appStack.clear()
            currentPkg = null
            lastEventAt = System.currentTimeMillis()
            return
        }

        // 通知栏 / 输入法 / 无界面组件：忽略，保留上一个真实应用
        val isApp = try {
            packageManager.getLaunchIntentForPackage(pkg) != null
        } catch (e: Exception) {
            false
        }
        if (!isApp) return

        if (appStack.lastOrNull() != pkg) {
            appStack.remove(pkg)
            appStack.addLast(pkg)
            if (appStack.size > 12) appStack.removeFirst()
        }
        currentPkg = pkg
        lastEventAt = System.currentTimeMillis()
    }

    override fun onInterrupt() {}
}

/** 桌面包名缓存 */
object Launchers {
    private var cached: Set<String> = emptySet()
    private var cachedAt = 0L

    fun warmUp(ctx: Context) {
        runCatching { cached = resolve(ctx); cachedAt = System.currentTimeMillis() }
    }

    fun isLauncher(ctx: Context, pkg: String): Boolean {
        if (cached.isEmpty() || System.currentTimeMillis() - cachedAt > 120_000L) {
            runCatching { cached = resolve(ctx); cachedAt = System.currentTimeMillis() }
        }
        return pkg in cached
    }

    private fun resolve(ctx: Context): Set<String> {
        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN)
            .addCategory(android.content.Intent.CATEGORY_HOME)
        return try {
            ctx.packageManager.queryIntentActivities(intent, 0)
                .mapNotNull { it.activityInfo?.packageName }
                .toSet()
        } catch (e: Exception) {
            emptySet()
        }
    }
}
