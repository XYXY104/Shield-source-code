package com.xy.shield

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout

/**
 * 桌面悬浮球：屏幕上方显示 XY 图标，可拖动，
 * 点击弹出守护弹窗（紧急拦截）。
 */
class BubbleService : Service() {

    private var wm: WindowManager? = null
    private var bubble: ImageView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!android.provider.Settings.canDrawOverlays(this)) return START_NOT_STICKY
        if (bubble == null) show()
        return START_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val size = dp(54)
        val radius = dp(18).toFloat()

        val iv = ImageView(this).apply {
            setImageResource(R.mipmap.ic_xy)
            scaleType = ImageView.ScaleType.CENTER_CROP
            // 圆角裁切：保持图片原样，只把四角磨圆
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, radius)
                }
            }
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = radius
            }
            elevation = dp(6).toFloat()
        }

        val params = WindowManager.LayoutParams(
            size, size,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(120)
        }

        var downX = 0f; var downY = 0f
        var startX = 0; var startY = 0
        var moved = false

        iv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    wm?.updateViewLayout(v, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {          // 点击（未拖动）→ 弹出守护弹窗
                        v.performClick()
                        startService(Intent(applicationContext,
                            OverlayService::class.java))
                    }
                    true
                }
                else -> false
            }
        }

        wm?.addView(iv, params)
        bubble = iv
    }

    private fun remove() {
        bubble?.let { runCatching { wm?.removeView(it) } }
        bubble = null
        stopSelf()
    }

    override fun onDestroy() {
        remove()
        super.onDestroy()
    }
}
