package com.xy.shield

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment() {

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_settings, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        v.findViewById<LinearLayout>(R.id.itemCoffee).setOnClickListener {
            showCoffeeDialog()
        }

        v.findViewById<LinearLayout>(R.id.itemWhitelist).setOnClickListener {
            WhitelistActivity.start(requireContext())
        }

        // 版本号从 APK 构建信息读取，自动跟随 build.gradle
        v.findViewById<TextView>(R.id.tvVersion).text = buildVersionText()
    }

    /** 形如 v2.5 (25) */
    private fun buildVersionText(): String = try {
        val pm = requireContext().packageManager
        val info = pm.getPackageInfo(requireContext().packageName, 0)
        @Suppress("DEPRECATION")
        val code = if (android.os.Build.VERSION.SDK_INT >= 28)
            info.longVersionCode else info.versionCode.toLong()
        "v${info.versionName} ($code)"
    } catch (e: Exception) {
        "v${BuildConfig.VERSION_NAME}"
    }

    private fun showCoffeeDialog() {
        val d = Dialog(requireContext())
        d.setContentView(R.layout.dialog_coffee)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.86).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT)
        d.findViewById<Button>(R.id.btnClose).setOnClickListener { d.dismiss() }
        d.show()
    }
}
