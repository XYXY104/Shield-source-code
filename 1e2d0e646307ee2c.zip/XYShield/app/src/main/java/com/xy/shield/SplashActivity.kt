package com.xy.shield

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * 启动页：圆角 XY 图标浮现 + 打字机动画
 * 「科技不是高高在上，而是服务于人民。」
 * 动画结束后进入主界面。
 */
class SplashActivity : AppCompatActivity() {

    private val fullText = "科技不是高高在上，而是服务于人民。"
    private val charDelay = 150L        // 每个字的间隔
    private val holdBeforeType = 700L   // 图标出现后停多久开始打字
    private val holdAfterType = 1300L    // 打完停多久进主页

    private lateinit var tvType: TextView
    private lateinit var tvCaret: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var caretVisible = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val img = findViewById<ImageView>(R.id.imgLogo)
        tvType = findViewById(R.id.tvType)
        tvCaret = findViewById(R.id.tvCaret)

        // 图标入场：缩放 + 淡入
        img.scaleX = 0.6f; img.scaleY = 0.6f; img.alpha = 0f
        val sx = ObjectAnimator.ofFloat(img, View.SCALE_X, 0.6f, 1f)
        val sy = ObjectAnimator.ofFloat(img, View.SCALE_Y, 0.6f, 1f)
        val al = ObjectAnimator.ofFloat(img, View.ALPHA, 0f, 1f)
        AnimatorSet().apply {
            playTogether(sx, sy, al)
            duration = 700
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }

        // 光标闪烁
        handler.postDelayed(object : Runnable {
            override fun run() {
                caretVisible = !caretVisible
                tvCaret.visibility = if (caretVisible) View.VISIBLE else View.INVISIBLE
                handler.postDelayed(this, 450)
            }
        }, 400)

        // 打字机
        handler.postDelayed({
            var i = 0
            val typer = object : Runnable {
                override fun run() {
                    if (i <= fullText.length) {
                        tvType.text = fullText.substring(0, i)
                        i++
                        handler.postDelayed(this, charDelay)
                    } else {
                        // 打完停一会再进主页
                        handler.postDelayed({ goMain() }, holdAfterType)
                    }
                }
            }
            handler.postDelayed(typer, holdBeforeType)
        }, 300)
    }

    private fun goMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
        // 平滑过渡
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
