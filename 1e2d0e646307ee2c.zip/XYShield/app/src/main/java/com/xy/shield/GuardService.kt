package com.xy.shield

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * 守护前台服务：
 * - 通知栏常驻「XY正在实时守护」
 * - START_STICKY：App 界面划掉后服务仍存活，系统也会自动拉起
 * - onTaskRemoved 时触发重启（双保险）
 * - 只有点「关闭守护」才会 stopSelf 真正退出
 */
class GuardService : Service() {

    companion object {
        const val CHANNEL_ID = "xy_guard"
        const val NOTI_ID = 1001
        const val ACTION_STOP = "com.xy.shield.STOP_GUARD"
        @JvmStatic var isRunning = false
    }

    private var screenReceiver: BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createChannel()
        startForeground(NOTI_ID, buildNotification())
        registerScreenReceiver()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "XY护盾守护",
                    NotificationManager.IMPORTANCE_LOW).apply {
                    description = "XY护盾实时守护状态"
                    setShowBadge(false)
                })
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val stop = PendingIntent.getService(this, 1,
            Intent(this, GuardService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID)
        else @Suppress("DEPRECATION") Notification.Builder(this)

        return b.setSmallIcon(R.mipmap.ic_xy)
            .setContentTitle("XY护盾")
            .setContentText("XY正在实时守护")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "关闭守护", stop)
            .build()
    }

    /** 监听屏幕开关，唤醒自己，避免被系统冻结 */
    private fun registerScreenReceiver() {
        screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                // 保持活跃
            }
        }
        runCatching {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
            else
                registerReceiver(screenReceiver, f)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            stopService(Intent(this, BubbleService::class.java))
            isRunning = false
            return START_NOT_STICKY
        }
        // 被系统杀掉后重建，刷新通知
        startForeground(NOTI_ID, buildNotification())
        return START_STICKY
    }

    /** 用户在最近任务里划掉 App 时：服务仍活着，这里再拉起一次 */
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (isRunning) {
            runCatching {
                val restart = Intent(applicationContext, GuardService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    applicationContext.startForegroundService(restart)
                else applicationContext.startService(restart)
            }
        }
    }

    override fun onDestroy() {
        isRunning = false
        screenReceiver?.let { runCatching { unregisterReceiver(it) } }
        super.onDestroy()
    }
}
