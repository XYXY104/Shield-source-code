package com.xy.shield

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri

/**
 * Shizuku 检测与跳转
 * 已安装 → 直接拉起 Shizuku App 本身；未安装 → 才去下载页
 */
object ShizukuHelper {

    private const val PKG = "moe.shizuku.privileged.api"

    fun checkInstalled(ctx: Context): Boolean {
        return try {
            ctx.packageManager.getPackageInfo(PKG, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /** Shizuku 服务是否在运行（已激活） */
    fun checkGranted(): Boolean {
        return try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java)
                .invoke(null, "shizuku")
            binder != null
        } catch (e: Throwable) {
            false
        }
    }

    /**
     * 直接打开 Shizuku 应用主界面。
     * 依次尝试多个入口，任意一个成功即可。
     */
    fun openShizuku(ctx: Context): Boolean {
        if (!checkInstalled(ctx)) return false

        val candidates = listOf(
            // 1. 启动图标（最通用）
            ctx.packageManager.getLaunchIntentForPackage(PKG),
            // 2. 设置页
            Intent().setClassName(PKG, "moe.shizuku.privileged.api.SettingsActivity"),
            // 3. 主页
            Intent().setClassName(PKG, "moe.shizuku.privileged.api.MainActivity")
        )

        for (c in candidates) {
            if (c == null) continue
            c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (runCatching { ctx.startActivity(c); true }.getOrDefault(false)) return true
        }
        return false
    }

    /** 兼容旧调用：有 Shizuku 就直接打开 App，没有才去下载 */
    fun requestPermission(ctx: Context) {
        if (!openShizuku(ctx)) openDownloadPage(ctx)
    }

    fun openDownloadPage(ctx: Context) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://shizuku.rikka.app/download/"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    /** 跳转系统卸载确认页 */
    fun openSystemUninstall(ctx: Context, pkg: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }
}
