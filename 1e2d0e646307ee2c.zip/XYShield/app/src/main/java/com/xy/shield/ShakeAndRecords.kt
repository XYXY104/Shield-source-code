package com.xy.shield

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ShakeDetector : SensorEventListener {
    private var sm: SensorManager? = null
    private var lastX = 0f; private var lastY = 0f; private var lastZ = 0f
    private var lastShake = 0L
    private var hasInit = false
    private var callback: (() -> Unit)? = null

    fun start(context: Context, cb: () -> Unit) {
        callback = cb
        sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        sm?.unregisterListener(this)
        sm = null
        hasInit = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = e.values[0]; val y = e.values[1]; val z = e.values[2]
        if (!hasInit) { lastX = x; lastY = y; lastZ = z; hasInit = true; return }
        val dx = x - lastX; val dy = y - lastY; val dz = z - lastZ
        lastX = x; lastY = y; lastZ = z
        val speed = Math.sqrt((dx * dx + dy * dy + dz * dz).toDouble())
        val now = System.currentTimeMillis()
        if (speed > 13 && now - lastShake > 1000) {
            lastShake = now
            callback?.invoke()
        }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}

data class Record(val time: String, val pkg: String, val action: String)

object RecordsStore {
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.CHINA)

    fun add(ctx: Context, pkg: String, action: String) {
        val sp = ctx.getSharedPreferences("records", Context.MODE_PRIVATE)
        val old = sp.getString("list", "") ?: ""
        val line = "${fmt.format(Date())}|$pkg|$action"
        sp.edit().putString("list", (line + "\n" + old).take(8000)).apply()
    }

    fun load(ctx: Context): List<Record> {
        val raw = ctx.getSharedPreferences("records", Context.MODE_PRIVATE)
            .getString("list", "") ?: ""
        return raw.lines().filter { it.isNotBlank() }.mapNotNull { l ->
            val parts = l.split("|")
            if (parts.size >= 3) Record(parts[0], parts[1], parts[2]) else null
        }
    }
}
