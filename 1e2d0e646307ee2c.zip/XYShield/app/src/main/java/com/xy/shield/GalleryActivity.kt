package com.xy.shield

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import java.io.File
import java.text.DecimalFormat

/**
 * 拆包图片画廊：
 *  - 三列网格展示 APK 内全部图片
 *  - 顶部可切换「全部 / 可疑图片」
 *  - 点击任意一张进入全屏查看器（可左右滑动）
 */
class GalleryActivity : AppCompatActivity() {

    companion object {
        /** 由 UnpackActivity 传入 */
        @JvmStatic
        var allImages: List<ApkScanner.ScannedImage> = emptyList()

        fun start(ctx: android.content.Context) {
            ctx.startActivity(Intent(ctx, GalleryActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private var showingHorrorOnly = false
    private lateinit var adapter: ThumbAdapter
    private lateinit var tvSub: TextView
    private lateinit var tvEmpty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        tvSub = findViewById(R.id.tvGallerySub)
        tvEmpty = findViewById(R.id.tvGalleryEmpty)
        val gv = findViewById<android.widget.GridView>(R.id.gvImages)
        val tabAll = findViewById<TextView>(R.id.tabAll)
        val tabHorror = findViewById<TextView>(R.id.tabHorror)

        findViewById<View>(R.id.btnBackGallery).setOnClickListener { finish() }

        adapter = ThumbAdapter()
        gv.adapter = adapter
        gv.setOnItemClickListener { _, _, position, _ ->
            val list = adapter.current()
            if (position in list.indices) {
                ImageViewerActivity.open(this, list, position)
            }
        }

        fun refreshTabs() {
            tabAll.setBackgroundResource(
                if (!showingHorrorOnly) R.drawable.bg_filter_on else R.drawable.bg_filter_off)
            tabAll.setTextColor(if (!showingHorrorOnly) 0xFFFFFFFF.toInt() else 0xFF8A8A98.toInt())
            tabAll.setTypeface(null,
                if (!showingHorrorOnly) android.graphics.Typeface.BOLD
                else android.graphics.Typeface.NORMAL)

            tabHorror.setBackgroundResource(
                if (showingHorrorOnly) R.drawable.bg_filter_on else R.drawable.bg_filter_off)
            tabHorror.setTextColor(if (showingHorrorOnly) 0xFFFFFFFF.toInt() else 0xFF8A8A98.toInt())
            tabHorror.setTypeface(null,
                if (showingHorrorOnly) android.graphics.Typeface.BOLD
                else android.graphics.Typeface.NORMAL)
        }

        tabAll.setOnClickListener {
            showingHorrorOnly = false
            refreshTabs()
            adapter.notifyDataSetChanged()
            updateSub()
        }
        tabHorror.setOnClickListener {
            showingHorrorOnly = true
            refreshTabs()
            adapter.notifyDataSetChanged()
            updateSub()
        }

        updateSub()
    }

    private fun updateSub() {
        val n = adapter.current().size
        val total = allImages.size
        tvSub.text = if (showingHorrorOnly) "可疑 $n 张 · 共 $total 张"
                      else "共 $total 张"
        tvEmpty.visibility = if (n == 0) View.VISIBLE else View.GONE
        tvEmpty.text = if (showingHorrorOnly) "没有检测到可疑图片" else "没有可显示的图片"
    }

    inner class ThumbAdapter : android.widget.BaseAdapter() {
        fun current(): List<ApkScanner.ScannedImage> =
            if (showingHorrorOnly) allImages.filter { it.horror } else allImages

        override fun getCount(): Int = current().size
        override fun getItem(position: Int): Any = current()[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: layoutInflater.inflate(
                R.layout.item_gallery_image, parent, false)
            val iv = v.findViewById<ImageView>(R.id.ivThumb)
            val badge = v.findViewById<TextView>(R.id.tvThumbBadge)

            val item = current()[position]
            v.tag = item

            iv.setImageDrawable(null)
            loadThumb(item.file, iv)
            badge.visibility = if (item.horror) View.VISIBLE else View.GONE
            return v
        }
    }

    private val main = Handler(Looper.getMainLooper())

    /** 缩略图：后台解码成小图，避免大图 OOM */
    private fun loadThumb(file: File, iv: ImageView) {
        iv.tag = file.absolutePath
        iv.setImageResource(R.drawable.bg_empty_circle)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP

        Thread {
            val bmp = decodeSampled(file, 220)
            main.post {
                if (iv.tag == file.absolutePath && bmp != null) {
                    iv.setImageBitmap(bmp)
                }
            }
        }.start()
    }

    private fun decodeSampled(file: File, target: Int): Bitmap? = runCatching {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        var scale = 1
        val maxDim = maxOf(opts.outWidth, opts.outHeight)
        while (maxDim / scale > target) scale *= 2
        val opts2 = BitmapFactory.Options().apply {
            inSampleSize = scale
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        BitmapFactory.decodeFile(file.absolutePath, opts2)
    }.getOrNull()
}
