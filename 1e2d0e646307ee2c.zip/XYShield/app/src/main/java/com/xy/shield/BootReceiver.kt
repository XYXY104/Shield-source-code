package com.xy.shield

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** 开机自启：重启后自动恢复守护 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val sp = context.getSharedPreferences("xy", Context.MODE_PRIVATE)
        if (!sp.getBoolean("guard_on", false)) return
        runCatching {
            val i = Intent(context, GuardService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                context.startForegroundService(i)
            else context.startService(i)
            context.startService(Intent(context, BubbleService::class.java))
        }
    }
}
