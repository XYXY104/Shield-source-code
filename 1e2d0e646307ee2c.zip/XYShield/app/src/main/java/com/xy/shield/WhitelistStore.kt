package com.xy.shield

import android.content.Context

/** 白名单：开着的应用不拦截，没开的拦截 */
object WhitelistStore {

    private const val SP = "whitelist"

    fun isAllowed(ctx: Context, pkg: String): Boolean =
        ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).getBoolean(pkg, false)

    fun setAllowed(ctx: Context, pkg: String, allowed: Boolean) {
        ctx.getSharedPreferences(SP, Context.MODE_PRIVATE)
            .edit().putBoolean(pkg, allowed).apply()
    }

    /** 是否被拦截：不在白名单里就拦 */
    fun shouldBlock(ctx: Context, pkg: String): Boolean = !isAllowed(ctx, pkg)

    data class AppEntry(
        val pkg: String,
        val label: String,
        val allowed: Boolean
    )

    /** 取全部「非系统」应用（排除自身），按名称排序 */
    fun loadApps(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val list = mutableListOf<AppEntry>()

        for (ai in AppClassifier.installedManagedApps(ctx)) {
            val label = runCatching {
                pm.getApplicationLabel(ai).toString()
            }.getOrDefault(ai.packageName)

            list.add(AppEntry(ai.packageName, label, isAllowed(ctx, ai.packageName)))
        }
        return list.sortedBy { it.label.lowercase() }
    }
}
