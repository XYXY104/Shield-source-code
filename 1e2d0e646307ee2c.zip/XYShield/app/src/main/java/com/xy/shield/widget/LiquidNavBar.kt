package com.xy.shield.widget

import android.annotation.SuppressLint
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat
import com.xy.shield.R
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 液态玻璃胶囊导航栏（原生实现，对应你给的 HTML 效果）：
 * - 半透明磨砂胶囊 + 阴影
 * - 果冻滑块：拖动时按速度横向拉伸、纵向压扁、圆角变大
 * - 松手回弹：cubic-bezier(0.34,1.56,0.64,1) 弹性落位
 * - 点击 / 拖动都能切换，支持三个标签
 */
class LiquidNavBar @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    // 四个标签
    var labels = arrayOf("主页", "记录", "聊天", "设置")
    private val icons = arrayOf(
        R.drawable.ic_tab_shield,
        R.drawable.ic_tab_records,
        R.drawable.ic_tab_chat,
        R.drawable.ic_tab_settings
    )

    var selectedIndex = 0
        private set

    var onTabSelected: ((Int) -> Unit)? = null

    private val itemCount = 4
    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#18FFFFFF")   // 白色 9% 透明度
    }
    private val barStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
        color = Color.parseColor("#22FFFFFF")
    }
    private val indicatorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#30FFFFFF")   // 白色 19%
    }
    private val indicatorStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
        color = Color.parseColor("#40FFFFFF")
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = dp(10f)
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private val barRect = RectF()
    private val indRect = RectF()
    private val iconRects = Array(itemCount) { RectF() }

    private var itemWidth = 0f
    private var indicatorLeft = 0f
    private var indicatorScaleX = 1f
    private var indicatorScaleY = 1f
    private var indicatorRadius = dp(36f)

    private var dragging = false
    private var hasMoved = false
    private var startX = 0f
    private var startLeft = 0f
    private var lastX = 0f
    private var lastTime = 0L
    private var pressIndex = 0

    private val activeColor = Color.parseColor("#0066FF")
    private val inactiveColor = Color.WHITE

    private val btnSize: Float get() = dp(72f)
    private val marginH: Float get() = dp(20f)
    private val marginBottom: Float get() = dp(14f)

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)   // 阴影 + 模糊需要软件层
        isClickable = true
        setBackgroundColor(Color.TRANSPARENT)     // 关键：控件本身必须透明，否则会露出底色
        // 关掉系统默认的可点击涟漪/高亮，避免出现色块
        isFocusable = false
        isFocusableInTouchMode = false
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (btnSize + marginBottom * 2).toInt())
    }

    override fun setBackgroundColor(color: Int) {
        super.setBackgroundColor(Color.TRANSPARENT)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val barLeft = marginH
        val barRight = w - marginH
        val barTop = marginBottom
        val barBottom = barTop + btnSize
        barRect.set(barLeft, barTop, barRight, barBottom)

        itemWidth = barRect.width() / itemCount
        indicatorRadius = btnSize / 2f
        snapTo(selectedIndex, animate = false)
    }

    override fun onDraw(canvas: Canvas) {
        // 1. 胶囊底：只画半透明玻璃本体，不画任何填充式阴影
        canvas.drawRoundRect(barRect, btnSize / 2f, btnSize / 2f, barPaint)
        canvas.drawRoundRect(barRect, btnSize / 2f, btnSize / 2f, barStrokePaint)

        // 2. 果冻滑块
        val scaleW = itemWidth * indicatorScaleX
        indRect.set(indicatorLeft, barRect.top + dp(5f),
            indicatorLeft + scaleW, barRect.bottom - dp(5f))
        canvas.drawRoundRect(indRect, indicatorRadius, indicatorRadius, indicatorPaint)
        canvas.drawRoundRect(indRect, indicatorRadius, indicatorRadius, indicatorStrokePaint)

        // 3. 图标 + 文字
        for (i in 0 until itemCount) {
            val cx = barRect.left + itemWidth * (i + 0.5f)
            val cy = barRect.centerY()
            val isActive = i == selectedIndex

            val iconSize = dp(24f)
            val iconTop = cy - dp(13f)
            val r = RectF(cx - iconSize / 2, iconTop,
                cx + iconSize / 2, iconTop + iconSize)
            iconRects[i] = r

            val d: Drawable = ContextCompat.getDrawable(context, icons[i])!!
            d.setBounds(r.left.toInt(), r.top.toInt(),
                r.right.toInt(), r.bottom.toInt())
            val tint = if (isActive) activeColor else inactiveColor
            d.setTint(tint)
            d.draw(canvas)

            textPaint.color = tint
            textPaint.alpha = if (isActive) 255 else 190
            canvas.drawText(labels[i], cx, barRect.bottom - dp(12f), textPaint)
        }
    }

    private fun snapTo(index: Int, animate: Boolean = true, onEnd: (() -> Unit)? = null) {
        val idx = index.coerceIn(0, itemCount - 1)
        val targetLeft = barRect.left + itemWidth * idx

        if (!animate) {
            selectedIndex = idx
            indicatorLeft = targetLeft
            indicatorScaleX = 1f
            indicatorScaleY = 1f
            indicatorRadius = btnSize / 2f
            invalidate()
            onEnd?.invoke()
            return
        }

        // 弹性回弹：cubic-bezier(0.34,1.56,0.64,1) 近似
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 380
        anim.interpolator = DecelerateInterpolator(1.4f)
        val from = indicatorLeft
        val fromScale = indicatorScaleX
        val fromScaleY = indicatorScaleY
        anim.addUpdateListener {
            val t = it.animatedValue as Float
            indicatorLeft = from + (targetLeft - from) * t
            indicatorScaleX = fromScale + (1f - fromScale) * t
            indicatorScaleY = fromScaleY + (1f - fromScaleY) * t
            indicatorRadius = btnSize / 2f * min(1f, 0.9f + t * 0.2f)
            invalidate()
        }
        anim.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                // 落位完成才真正切换页面并变蓝
                selectedIndex = idx
                pressIndex = idx
                invalidate()
                onEnd?.invoke()
            }
        })
        anim.start()
        invalidate()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                hasMoved = false
                startX = e.x
                lastX = e.x
                lastTime = System.currentTimeMillis()
                startLeft = indicatorLeft
                // 点击的是哪个标签
                pressIndex = ((e.x - barRect.left) / itemWidth)
                    .toInt().coerceIn(0, itemCount - 1)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                val now = System.currentTimeMillis()
                val dt = max(1L, now - lastTime)
                val dx = e.x - lastX
                val totalDx = e.x - startX
                if (abs(totalDx) > dp(5f)) hasMoved = true

                val speed = abs(dx / dt)          // px/ms
                lastX = e.x
                lastTime = now

                val maxLeft = barRect.right - itemWidth
                indicatorLeft = (startLeft + totalDx)
                    .coerceIn(barRect.left, maxLeft)

                // 果冻形变
                val s = min(speed * 0.35f, 0.30f)
                indicatorScaleX = 1f + s
                indicatorScaleY = 1f - s * 0.65f
                indicatorRadius = min(btnSize / 2f + speed * dp(6f), dp(60f))

                // 拖动过程中不改变选中项，只有落位后才切换
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) return false
                dragging = false
                val idx = if (hasMoved) {
                    ((indicatorLeft - barRect.left) / itemWidth)
                        .roundToInt().coerceIn(0, itemCount - 1)
                } else pressIndex

                // 先让滑块落位动画跑起来，动画结束后再切页 + 变蓝
                snapTo(idx, animate = true) {
                    onTabSelected?.invoke(idx)
                }
                performClick()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    /** 外部代码切换 */
    fun select(index: Int) {
        snapTo(index, animate = true) { onTabSelected?.invoke(index) }
    }
}
