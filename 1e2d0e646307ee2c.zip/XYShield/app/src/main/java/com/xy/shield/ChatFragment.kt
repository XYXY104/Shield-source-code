package com.xy.shield

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 聊天室页面。
 * 连上 → 正常收发（文字 + 图片）；连不上 → 顶部红条显示「连接失败」+ 重试。
 */
class ChatFragment : Fragment(), ChatClient.Listener {

    private lateinit var llChat: LinearLayout
    private lateinit var svChat: ScrollView
    private lateinit var etChat: EditText
    private lateinit var btnSend: View
    private lateinit var tvSub: TextView
    private lateinit var dot: View
    private lateinit var cardError: View
    private lateinit var tvError: TextView

    private val GREEN = 0xFF4FC76A.toInt()
    private val ORANGE = 0xFFE8A33D.toInt()
    private val RED = 0xFFDE4A4A.toInt()

    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    private var connected = false

    /** 待发送的图片：选好图后立刻上传，成功后暂存 path */
    private var pendingImagePath: String? = null
    private var uploading = false

    private val pickImage = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) handlePickedImage(uri)
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_chat, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        llChat = v.findViewById(R.id.llChat)
        svChat = v.findViewById(R.id.svChat)
        etChat = v.findViewById(R.id.etChat)
        btnSend = v.findViewById(R.id.btnSendIcon)
        tvSub = v.findViewById(R.id.tvChatSub)
        dot = v.findViewById(R.id.dotChat)
        cardError = v.findViewById(R.id.cardChatError)
        tvError = v.findViewById(R.id.tvChatError)

        btnSend.setOnClickListener { send() }

        // 选图
        v.findViewById<View>(R.id.btnChatImage).setOnClickListener {
            if (!connected) {
                toast("连接失败，请先点重试")
                return@setOnClickListener
            }
            pickImage.launch("image/*")
        }

        // @
        v.findViewById<View>(R.id.btnChatAt).setOnClickListener {
            etChat.append("@")
            etChat.requestFocus()
        }

        v.findViewById<View>(R.id.btnChatRetry).setOnClickListener {
            showConnecting()
            ChatClient.connect()
        }

        ChatClient.attach(this)
        if (!ChatClient.isConnected) {
            showConnecting()
            ChatClient.connect()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        if (!isAdded) return
        android.widget.Toast.makeText(requireContext(), msg, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun showConnecting() {
        connected = false
        cardError.visibility = View.GONE
        dot.background = circle(ORANGE)
        tvSub.text = "正在连接…"
        tvSub.setTextColor(0xFFA7A594.toInt())
    }

    private fun showConnected() {
        connected = true
        cardError.visibility = View.GONE
        dot.background = circle(GREEN)
        tvSub.setTextColor(GREEN)
    }

    // ── 选图 → 压缩 → 上传 ──

    private fun handlePickedImage(uri: Uri) {
        val ctx = context ?: return
        if (uploading) {
            toast("正在上传上一张图片")
            return
        }
        uploading = true
        tvSub.text = "正在上传图片…"

        Thread {
            val bytes = compressImage(uri)
            if (bytes == null) {
                uploading = false
                activity?.runOnUiThread {
                    toast("图片读取失败")
                    restoreSub()
                }
                return@Thread
            }
            ChatClient.uploadImage(bytes, "image/jpeg", object : ChatClient.UploadCallback {
                override fun onSuccess(path: String) {
                    uploading = false
                    pendingImagePath = path
                    tvSub.text = "图片已就绪 · 点发送或输入文字一起发出"
                    toast("图片上传成功，点发送即可发出")
                }

                override fun onFailed(reason: String) {
                    uploading = false
                    restoreSub()
                    toast("上传失败：$reason")
                }
            })
        }.start()
    }

    /** 压缩到最长边 1280、JPEG 82%，避免传输过大 */
    private fun compressImage(uri: Uri): ByteArray? = runCatching {
        val ctx = requireContext().applicationContext

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, bounds)
        }
        if (bounds.outWidth <= 0) return@runCatching null

        var scale = 1
        val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
        while (maxDim / scale > 1280) scale *= 2

        val opts = BitmapFactory.Options().apply {
            inSampleSize = scale
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: return@runCatching null

        // 二次精缩到 1280 以内
        val w = bmp.width
        val h = bmp.height
        val longest = maxOf(w, h)
        val finalBmp = if (longest > 1280) {
            val r = 1280f / longest
            val s = Bitmap.createScaledBitmap(bmp, (w * r).toInt(), (h * r).toInt(), true)
            if (s !== bmp) bmp.recycle()
            s
        } else bmp

        val out = ByteArrayOutputStream()
        finalBmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
        finalBmp.recycle()
        out.toByteArray()
    }.getOrNull()

    private fun restoreSub() {
        if (!isAdded || !connected) return
        tvSub.text = "已连接 · 我是 ${ChatClient.myName}"
    }

    // ── ChatClient.Listener ──

    override fun onConnected(name: String, online: Int) {
        if (!isAdded) return
        showConnected()
        tvSub.text = "已连接 · 我是 $name · $online 人在线"
    }

    override fun onOnline(online: Int, users: List<String>) {
        if (!isAdded || !connected) return
        tvSub.text = "已连接 · 我是 ${ChatClient.myName} · $online 人在线"
    }

    override fun onMessage(msg: ChatClient.Message) {
        if (!isAdded) return
        addBubble(msg)
    }

    override fun onDisconnected(reason: String) {
        if (!isAdded) return
        connected = false
        dot.background = circle(RED)
        tvSub.text = "连接失败"
        tvSub.setTextColor(RED)
        cardError.visibility = View.VISIBLE
        tvError.text = "连接失败：$reason"
    }

    // ── 发送 ──

    private fun send() {
        val text = etChat.text.toString().trim()
        val img = pendingImagePath

        if (text.isEmpty() && img == null) return

        if (!connected) {
            cardError.visibility = View.VISIBLE
            tvError.text = "连接失败：未连接到服务器，请点重试"
            return
        }

        if (ChatClient.send(text, img)) {
            etChat.setText("")
            pendingImagePath = null
            restoreSub()
        } else {
            onDisconnected("发送失败")
        }
    }

    // ── 气泡渲染 ──

    private fun addBubble(msg: ChatClient.Message) {
        val ctx = context ?: return

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (msg.self) Gravity.END else Gravity.START
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        }

        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (msg.self) Gravity.END else Gravity.START
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val head = TextView(ctx).apply {
            text = if (msg.self) "我 · ${timeFmt.format(Date(msg.time))}"
                   else "${msg.name} · ${timeFmt.format(Date(msg.time))}"
            textSize = 10f
            setTextColor(0xFFA7A594.toInt())
            gravity = if (msg.self) Gravity.END else Gravity.START
            setPadding(dp(6), 0, dp(6), dp(5))
        }
        col.addView(head)

        // 图片气泡
        val imgPath = msg.imagePath
        if (!imgPath.isNullOrBlank()) {
            col.addView(buildImageBubble(msg.self, imgPath))
        }

        // 文字气泡
        if (msg.text.isNotBlank()) {
            val bubble = TextView(ctx).apply {
                text = msg.text
                textSize = 14f
                setLineSpacing(dp(4).toFloat(), 1f)
                setTextColor(if (msg.self) 0xFFFFFFFF.toInt() else 0xFF3E3D33.toInt())
                background = ContextCompat.getDrawable(
                    ctx, if (msg.self) R.drawable.bg_bubble_me else R.drawable.bg_bubble_other)
                setPadding(dp(15), dp(11), dp(15), dp(11))
                maxWidth = (resources.displayMetrics.widthPixels * 0.68f).toInt()
            }
            col.addView(bubble, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = if (imgPath.isNullOrBlank()) 0 else dp(6) })
        }

        row.addView(col)
        llChat.addView(row)
        svChat.post { svChat.fullScroll(View.FOCUS_DOWN) }
    }

    /** 图片气泡：圆角卡片，点击全屏查看 */
    private fun buildImageBubble(self: Boolean, path: String): View {
        val ctx = context ?: return View(requireContext())

        val maxW = (resources.displayMetrics.widthPixels * 0.62f).toInt()

        val frame = FrameLayout(ctx).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadii = floatArrayOf(
                    if (self) dp(20).toFloat() else dp(6).toFloat(),
                    if (self) dp(20).toFloat() else dp(6).toFloat(),
                    if (self) dp(6).toFloat() else dp(20).toFloat(),
                    if (self) dp(6).toFloat() else dp(20).toFloat(),
                    dp(20).toFloat(), dp(20).toFloat(),
                    dp(20).toFloat(), dp(20).toFloat()
                )
                setColor(0xFFE9EDF5.toInt())
            }
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(18).toFloat())
                }
            }
            layoutParams = LinearLayout.LayoutParams(maxW, dp(180)).apply {
                topMargin = 0
            }
        }

        val iv = ImageView(ctx).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "聊天图片"
            setImageResource(R.drawable.bg_empty_circle)
        }
        frame.addView(iv)

        // 加载中提示
        val loading = TextView(ctx).apply {
            text = "加载中…"
            textSize = 11f
            setTextColor(0xFF8A8A98.toInt())
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT)
        }
        frame.addView(loading)

        val fullUrl = ChatClient.imageUrl(path)

        // 网络加载图片
        Thread {
            val bmp = downloadBitmap(fullUrl)
            activity?.runOnUiThread {
                if (bmp != null) {
                    loading.visibility = View.GONE
                    iv.setImageBitmap(bmp)
                    // 按图片比例调整高度
                    val ratio = bmp.height.toFloat() / bmp.width.toFloat()
                    val h = (maxW * ratio).toInt().coerceIn(dp(90), dp(320))
                    frame.layoutParams = (frame.layoutParams as LinearLayout.LayoutParams).apply {
                        height = h
                    }
                } else {
                    loading.text = "图片加载失败"
                    loading.setTextColor(0xFFDE4A4A.toInt())
                }
            }
        }.start()

        // 点击全屏查看
        frame.setOnClickListener {
            val bmp = (iv.drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap
            if (bmp != null) {
                showFullImage(bmp)
            } else {
                toast("图片还在加载")
            }
        }

        return frame
    }

    /** 全屏查看聊天图片 */
    private fun showFullImage(bmp: Bitmap) {
        val ctx = requireContext()
        val d = android.app.Dialog(ctx, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val iv = ImageView(ctx).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
        }
        d.setContentView(iv)
        iv.setOnClickListener { d.dismiss() }
        d.show()
    }

    private fun downloadBitmap(url: String): Bitmap? = runCatching {
        val req = okhttp3.Request.Builder().url(url).build()
        okhttp3.OkHttpClient.Builder()
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
            .build()
            .newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val bytes = resp.body?.bytes() ?: return@use null
                // 采样解码，避免大图 OOM
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var scale = 1
                val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
                while (maxDim / scale > 1200) scale *= 2
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size,
                    BitmapFactory.Options().apply {
                        inSampleSize = scale
                        inPreferredConfig = Bitmap.Config.RGB_565
                    })
            }
    }.getOrNull()

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        ChatClient.detach()
    }
}
