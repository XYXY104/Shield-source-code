package com.xy.shield

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * 摇一摇紧急拦截弹窗（美化版）：
 * 全屏半透明黑色遮罩 + 居中一张大圆角深色卡片
 * 卡片内：圆形光圈绿盾 + 标题 + 说明 + 当前应用胶囊 + 三个超圆角按钮
 */
class OverlayService : Service() {

    private var wm: WindowManager? = null
    private var root: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!android.provider.Settings.canDrawOverlays(this)) return START_NOT_STICKY
        if (root == null) show()
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun labelOf(pkg: String?): String {
        if (pkg == null) return "未知应用"
        return try {
            val pm = packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }
    }

    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // 全屏半透明黑色遮罩（点空白处不关闭，必须走按钮）
        val overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#CC0B0A06")) // 约80%不透明的深黑
            setPadding(dp(26), dp(26), dp(26), dp(26))
        }

        // 居中大圆角深色卡片
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(Color.parseColor("#F2141712"), 34) // 深色超圆角卡片
            setPadding(dp(26), dp(30), dp(26), dp(26))
        }

        // ── 圆形光圈 + 绿盾 ──
        val halo = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1F3DCB60"))
            }
            layoutParams = LinearLayout.LayoutParams(dp(104), dp(104))
        }
        val haloRing = ImageView(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), Color.parseColor("#4A5BD873"))
            }
        }
        halo.addView(haloRing, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val shield = ImageView(this).apply {
            setImageResource(R.drawable.ic_shield_check)
            layoutParams = FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER)
        }
        halo.addView(shield)

        // ── 标题 ──
        val title = TextView(this).apply {
            text = "XY护盾 · 紧急拦截"
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, dp(6))
        }

        // ── 说明 ──
        val desc = TextView(this).apply {
            text = "检测到异常应用无法退出？\n点击下方按钮立即回到桌面并清理后台。"
            textSize = 13f
            setTextColor(Color.parseColor("#9BA096"))
            gravity = Gravity.CENTER
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(0, 0, 0, dp(16))
        }

        // ── 当前应用：实时查询，不吃缓存亏 ──
        var pkgNow = ShieldAccessibilityService.refresh(this)
        var sysNow = pkgNow != null && AppClassifier.isSystemApp(this, pkgNow)

        val appChip = TextView(this).apply {
            text = "当前应用：${labelOf(pkgNow)}"
            textSize = 13f
            setTextColor(if (sysNow) Color.parseColor("#F0D9A8") else Color.parseColor("#CFE8D4"))
            setTypeface(typeface, Typeface.BOLD)
            background = rounded(
                if (sysNow) Color.parseColor("#26E0B458") else Color.parseColor("#223DCB60"), 20)
            setPadding(dp(18), dp(8), dp(18), dp(8))
            gravity = Gravity.CENTER
            maxWidth = dp(280)
        }

        // ── 状态标识 ──
        val sysTag = TextView(this).apply {
            text = if (pkgNow == null) "未检测到前台应用 · 点此重新检测"
                   else if (sysNow) "系统应用 · 不处理"
                   else "用户应用 · 可卸载"
            textSize = 11f
            setTextColor(
                if (pkgNow == null) Color.parseColor("#E88A8A")
                else if (sysNow) Color.parseColor("#E0B458")
                else Color.parseColor("#7BB88A"))
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), 0)
        }

        // ── 超圆角按钮 ──
        fun mkBtn(text: String, bg: Int, txt: Int): Button = Button(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(txt)
            setTypeface(typeface, Typeface.BOLD)
            background = rounded(bg, 28) // 超圆角
            stateListAnimator = null
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54)).apply {
                topMargin = dp(14)
            }
        }

        val btnBlock = mkBtn("立即拦截 · 强力清除后台",
            Color.parseColor("#E03A44"), Color.WHITE)
        val btnUninstall = mkBtn("卸载该应用（跳系统卸载）",
            Color.parseColor("#2F9E52"), Color.WHITE)
        val btnHide = mkBtn("收起（不拦截）",
            Color.parseColor("#2A2E26"), Color.parseColor("#B9BDB2"))

        // 系统应用：卸载按钮置灰不可点
        // 未检测到：按钮可点，点下去会重新检测
        if (sysNow) {
            btnUninstall.text = "系统应用 · 不处理"
            btnUninstall.background = rounded(Color.parseColor("#23261F"), 28)
            btnUninstall.setTextColor(Color.parseColor("#6E7267"))
            btnUninstall.isEnabled = false
        } else if (pkgNow == null) {
            btnUninstall.text = "重新检测并卸载"
            btnUninstall.background = rounded(Color.parseColor("#E8A33D"), 28)
        }

        btnUninstall.setOnClickListener {
            // 每次点击都重新查一遍，避免用了过期包名
            val p = ShieldAccessibilityService.refresh(this)
            if (p.isNullOrEmpty()) {
                sysTag.text = "仍未检测到前台应用，请先打开目标应用再摇一摇"
                return@setOnClickListener
            }
            if (AppClassifier.isSystemApp(this, p)) {
                sysTag.text = "系统应用 · 不处理"
                return@setOnClickListener
            }
            RecordsStore.add(applicationContext, p, "跳转系统卸载")
            remove()
            launchUninstall(p)
        }

        // 未检测到时，点状态文字可重试
        sysTag.setOnClickListener {
            val p = ShieldAccessibilityService.refresh(this)
            pkgNow = p
            sysNow = p != null && AppClassifier.isSystemApp(this, p)
            appChip.text = "当前应用：${labelOf(p)}"
            sysTag.text = when {
                p == null -> "仍未检测到 · 请打开目标应用后再试"
                sysNow -> "系统应用 · 不处理"
                else -> "用户应用 · 可卸载"
            }
            if (p != null && !sysNow) {
                btnUninstall.text = "卸载该应用（跳系统卸载）"
                btnUninstall.background = rounded(Color.parseColor("#2F9E52"), 28)
            }
        }

        btnBlock.setOnClickListener {
            val pkg = ShieldAccessibilityService.refresh(this)
            if (!pkg.isNullOrEmpty()) {
                RecordsStore.add(applicationContext, pkg, "强力拦截·清后台")
            }
            runCatching {
                val home = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(home)
            }
            remove()
        }

        btnHide.setOnClickListener {
            RecordsStore.add(applicationContext,
                ShieldAccessibilityService.currentPkg ?: "-", "收起（不拦截）")
            remove()
        }

        card.addView(halo, 0)
        card.addView(title)
        card.addView(desc)
        card.addView(appChip)
        card.addView(sysTag)
        card.addView(btnBlock)
        card.addView(btnUninstall)
        card.addView(btnHide)

        overlay.addView(card)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        wm?.addView(overlay, params)
        root = overlay
    }

    private fun isSystemApp(pkg: String): Boolean = AppClassifier.isSystemApp(this, pkg)

    /**
     * 跳系统卸载页，多路兜底：
     *  1. ACTION_DELETE —— 标准卸载确认页
     *  2. ACTION_UNINSTALL_PACKAGE —— 老接口，部分 ROM 只认这个
     *  3. 应用详情页 —— 有些 ROM 屏蔽了 DELETE 但详情页有卸载按钮
     *  4. 应用列表页 —— 最后兜底
     */
    private fun launchUninstall(pkg: String) {
        val uri = android.net.Uri.parse("package:$pkg")

        val intents = listOf(
            Intent(Intent.ACTION_DELETE, uri)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            Intent(Intent.ACTION_UNINSTALL_PACKAGE, uri)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            Intent(android.provider.Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )

        for (it in intents) {
            val ok = runCatching { startActivity(it); true }.getOrDefault(false)
            if (ok) return
        }
        android.widget.Toast.makeText(this, "无法打开卸载页面，请到设置中手动卸载",
            android.widget.Toast.LENGTH_LONG).show()
    }

    private fun remove() {
        root?.let { runCatching { wm?.removeView(it) } }
        root = null
        stopSelf()
    }

    override fun onDestroy() {
        remove()
        super.onDestroy()
    }
}
