package com.xy.shield

import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.DecimalFormat

/**
 * 拆解应用页：
 *  1. 选 APK → 2. 点开始拆解 → 3. 解包分析 → 4. 出结论
 *  病毒判定：恐怖图片 + 硬编码密码 同时命中
 */
class UnpackActivity : AppCompatActivity() {

    private lateinit var tvPickTitle: TextView
    private lateinit var tvPickSub: TextView
    private lateinit var btnStart: TextView
    private lateinit var llProgress: LinearLayout
    private lateinit var tvProgress: TextView
    private lateinit var pb: ProgressBar

    private lateinit var cardResult: View
    private lateinit var tvVerdict: TextView
    private lateinit var tvVerdictSub: TextView
    private lateinit var cardDetail: View
    private lateinit var tvFileInfo: TextView
    private lateinit var tvPwdResult: TextView
    private lateinit var tvHorrorResult: TextView
    private lateinit var llHits: LinearLayout
    private lateinit var cardImagePreview: View
    private lateinit var tvPreviewTitle: TextView
    private lateinit var llThumbs: LinearLayout

    private var pickedUri: Uri? = null
    private var pickedName: String = ""
    private var scanning = false
    private var lastImages: List<ApkScanner.ScannedImage> = emptyList()

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            pickedUri = uri
            pickedName = queryName(uri) ?: "selected.apk"
            tvPickTitle.text = pickedName
            tvPickSub.text = "已选择 · 点击下方开始拆解"
            tvPickSub.setTextColor(Color.parseColor("#4A7BE0"))
            cardResult.visibility = View.GONE
            cardDetail.visibility = View.GONE
            llHits.removeAllViews()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_unpack)

        tvPickTitle = findViewById(R.id.tvPickTitle)
        tvPickSub = findViewById(R.id.tvPickSub)
        btnStart = findViewById(R.id.btnStartScan)
        llProgress = findViewById(R.id.llProgress)
        tvProgress = findViewById(R.id.tvProgress)
        pb = findViewById(R.id.pbScan)
        cardResult = findViewById(R.id.cardResult)
        tvVerdict = findViewById(R.id.tvVerdict)
        tvVerdictSub = findViewById(R.id.tvVerdictSub)
        cardDetail = findViewById(R.id.cardDetail)
        tvFileInfo = findViewById(R.id.tvFileInfo)
        tvPwdResult = findViewById(R.id.tvPwdResult)
        tvHorrorResult = findViewById(R.id.tvHorrorResult)
        llHits = findViewById(R.id.llHits)
        cardImagePreview = findViewById(R.id.cardImagePreview)
        tvPreviewTitle = findViewById(R.id.tvPreviewTitle)
        llThumbs = findViewById(R.id.llThumbs)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }

        // 查看全部拆包图片
        findViewById<View>(R.id.btnViewAll).setOnClickListener {
            if (lastImages.isEmpty()) {
                toast("没有可查看的图片")
                return@setOnClickListener
            }
            GalleryActivity.allImages = lastImages
            GalleryActivity.start(this)
        }

        findViewById<View>(R.id.cardPick).setOnClickListener {
            if (scanning) return@setOnClickListener
            picker.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream", "*/*"))
        }

        btnStart.setOnClickListener { startScan() }
    }

    private fun startScan() {
        val uri = pickedUri
        if (uri == null) {
            toast("请先选择一个 APK 文件")
            return
        }
        if (scanning) return
        scanning = true

        btnStart.text = "正在拆解…"
        btnStart.alpha = 0.6f
        llProgress.visibility = View.VISIBLE
        cardResult.visibility = View.GONE
        cardDetail.visibility = View.GONE
        cardImagePreview.visibility = View.GONE
        llHits.removeAllViews()
        pb.progress = 0
        lastImages = emptyList()

        Thread {
            try {
                val result = ApkScanner.scan(this, uri, pickedName) { label, pct ->
                    runOnUiThread {
                        tvProgress.text = label
                        pb.progress = pct
                    }
                }
                runOnUiThread { showResult(result) }
            } catch (e: Exception) {
                runOnUiThread {
                    toast("拆解失败：${e.message ?: "文件无法解析"}")
                    resetButton()
                }
            }
        }.start()
    }

    private fun showResult(r: ApkScanner.Result) {
        resetButton()
        llProgress.visibility = View.GONE

        cardResult.visibility = View.VISIBLE
        cardDetail.visibility = View.VISIBLE

        if (r.isVirus) {
            cardResult.setBackgroundResource(R.drawable.bg_result_virus)
            tvVerdict.text = "判定为病毒"
            tvVerdict.setTextColor(Color.parseColor("#C62828"))
            tvVerdictSub.setText("该 APK 同时含有恐怖图片与硬编码密码，高风险")
            tvVerdictSub.setTextColor(Color.parseColor("#B06060"))
        } else {
            cardResult.setBackgroundResource(R.drawable.bg_result_clean)
            tvVerdict.text = "未发现风险"
            tvVerdict.setTextColor(Color.parseColor("#2E7D32"))
            val reason = when {
                !r.hasHorrorImage && !r.hasHardcodedPassword ->
                    "未检测到恐怖图片，也未发现硬编码密码"
                r.hasHorrorImage -> "检测到恐怖图片，但未发现硬编码密码"
                else -> "检测到硬编码密码，但未发现恐怖图片"
            }
            tvVerdictSub.text = reason
            tvVerdictSub.setTextColor(Color.parseColor("#6B7A6E"))
        }

        tvFileInfo.text = buildString {
            append("文件：${r.fileName}\n")
            append("大小：${formatSize(r.sizeBytes)}\n")
            append("文件数：${r.fileCount} · 图片 ${r.imageCount} · dex ${r.dexCount}")
        }

        tvPwdResult.text = if (r.hasHardcodedPassword)
            "硬编码密码：检出 ${r.passwordHits.size} 处"
        else
            "硬编码密码：未检出"

        tvHorrorResult.text = if (r.hasHorrorImage)
            "恐怖图片：检出 ${r.horrorHits.size} 处"
        else
            "恐怖图片：未检出"

        // 命中明细
        r.passwordHits.forEach { addHitCard("硬编码密码", it, true) }
        r.horrorHits.forEach { addHitCard("恐怖图片", it, true) }
        r.findings.filter { it.title != "检测到恐怖图片" && it.title != "检测到硬编码密码" }
            .forEach { addHitCard(it.title, it.detail, false) }

        // 拆包图片预览
        lastImages = r.images
        renderThumbs(r)
    }

    /** 横向缩略图条：可疑的排前面 */
    private fun renderThumbs(r: ApkScanner.Result) {
        llThumbs.removeAllViews()
        if (r.images.isEmpty()) {
            cardImagePreview.visibility = View.GONE
            return
        }
        cardImagePreview.visibility = View.VISIBLE

        val horrorCount = r.images.count { it.horror }
        tvPreviewTitle.text = if (horrorCount > 0)
            "拆包图片 · 可疑 $horrorCount 张 / 共 ${r.images.size} 张"
        else
            "拆包图片 · 共 ${r.images.size} 张"

        val ordered = r.images.sortedByDescending { it.horror }

        ordered.take(12).forEach { img ->
            val box = android.widget.FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(84), dp(84)).apply {
                    marginEnd = dp(8)
                }
                background = getDrawable(R.drawable.bg_empty_circle)
                clipToOutline = true
                this.outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: android.graphics.Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, dp(14).toFloat())
                    }
                }
            }

            val iv = ImageView(this).apply {
                layoutParams = android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT)
                scaleType = ImageView.ScaleType.CENTER_CROP
                contentDescription = img.entryName
            }
            box.addView(iv)

            // 可疑角标
            if (img.horror) {
                val badge = TextView(this).apply {
                    text = "可疑"
                    textSize = 8f
                    setTextColor(Color.WHITE)
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    background = getDrawable(R.drawable.bg_badge_admin)
                    setPadding(dp(5), dp(1), dp(5), dp(1))
                    layoutParams = android.widget.FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { gravity = android.view.Gravity.TOP or android.view.Gravity.END
                        topMargin = dp(4); marginEnd = dp(4) }
                }
                box.addView(badge)
            }

            // 异步解码缩略图
            Thread {
                val bmp = decodeSampled(img.file, 200)
                runOnUiThread { if (bmp != null) iv.setImageBitmap(bmp) }
            }.start()

            box.setOnClickListener {
                val idx = ordered.indexOf(img).coerceAtLeast(0)
                ImageViewerActivity.open(this, ordered, idx)
            }

            llThumbs.addView(box)
        }
    }

    private fun decodeSampled(file: java.io.File, target: Int): android.graphics.Bitmap? =
        runCatching {
            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(file.absolutePath, o)
            var scale = 1
            val maxDim = maxOf(o.outWidth, o.outHeight)
            while (maxDim / scale > target) scale *= 2
            android.graphics.BitmapFactory.decodeFile(file.absolutePath,
                android.graphics.BitmapFactory.Options().apply {
                    inSampleSize = scale
                    inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
                })
        }.getOrNull()

    private fun addHitCard(tag: String, text: String, danger: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(
                if (danger) R.drawable.bg_error_bar else R.drawable.bg_card)
            setPadding(dp(16), dp(13), dp(16), dp(13))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        }

        val tvTag = TextView(this).apply {
            this.text = tag
            textSize = 10f
            setTextColor(if (danger) Color.parseColor("#C43A3A") else Color.parseColor("#7C7A68"))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val tvBody = TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextColor(Color.parseColor("#5C5B50"))
            setPadding(0, dp(5), 0, 0)
            setLineSpacing(dp(3).toFloat(), 1f)
        }

        card.addView(tvTag)
        card.addView(tvBody)
        llHits.addView(card)
    }

    private fun resetButton() {
        scanning = false
        btnStart.text = "开始拆解"
        btnStart.alpha = 1f
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun queryName(uri: Uri): String? {
        var name: String? = null
        var c: Cursor? = null
        try {
            c = contentResolver.query(uri, null, null, null, null)
            if (c != null && c.moveToFirst()) {
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = c.getString(idx)
            }
        } catch (e: Exception) {
            // ignore
        } finally {
            c?.close()
        }
        return name
    }

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val kb = bytes / 1024.0
        if (kb < 1024) return DecimalFormat("0.0").format(kb) + " KB"
        return DecimalFormat("0.0").format(kb / 1024.0) + " MB"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        fun start(ctx: android.content.Context) {
            ctx.startActivity(Intent(ctx, UnpackActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
