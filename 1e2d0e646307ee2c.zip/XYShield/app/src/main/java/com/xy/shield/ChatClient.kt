package com.xy.shield

import android.os.Handler
import android.os.Looper
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * 聊天室客户端（WebSocket + HTTP 图片上传）。
 *
 * 连不上 / 断开 → 回调 onDisconnected，界面显示「连接失败」。
 */
object ChatClient {

    private const val SHARE_CODE = "FUA6SR7EMP"
    private const val HOST = "a3342c5117d7be863.app.workbuddy.host"

    private const val WS_URL = "wss://$HOST/ws?sharecode=$SHARE_CODE"
    private const val UPLOAD_URL = "https://$HOST/upload?sharecode=$SHARE_CODE"

    /** 把服务端返回的 /img/xxx 拼成可访问的完整地址 */
    fun imageUrl(path: String): String {
        if (path.startsWith("http")) return path
        return "https://$HOST$path?sharecode=$SHARE_CODE"
    }

    data class Message(
        val name: String,
        val text: String,
        val time: Long,
        val self: Boolean,
        val imagePath: String? = null
    )

    interface Listener {
        fun onConnected(name: String, online: Int)
        fun onOnline(online: Int, users: List<String>)
        fun onMessage(msg: Message)
        fun onDisconnected(reason: String)
    }

    interface UploadCallback {
        fun onSuccess(path: String)
        fun onFailed(reason: String)
    }

    private val main = Handler(Looper.getMainLooper())

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .pingInterval(25, TimeUnit.SECONDS)
            .build()
    }

    private var ws: WebSocket? = null
    private var listener: Listener? = null
    private var connecting = false

    var myName: String = ""
        private set

    val isConnected: Boolean
        get() = ws != null && !connecting

    fun attach(l: Listener) {
        listener = l
    }

    fun detach() {
        listener = null
    }

    fun connect() {
        if (ws != null || connecting) return
        connecting = true

        val req = Request.Builder().url(WS_URL).build()
        ws = http.newWebSocket(req, object : WebSocketListener() {

            override fun onOpen(webSocket: WebSocket, response: Response) {
                connecting = false
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                runCatching {
                    val o = JSONObject(text)
                    when (o.optString("type")) {
                        "welcome" -> {
                            val name = o.optString("name")
                            val online = o.optInt("online", 1)
                            myName = name

                            val arr: JSONArray = o.optJSONArray("history") ?: JSONArray()
                            val list = mutableListOf<Message>()
                            for (i in 0 until arr.length()) {
                                val m = arr.getJSONObject(i)
                                list.add(Message(
                                    name = m.optString("name"),
                                    text = m.optString("text"),
                                    time = m.optLong("time"),
                                    self = m.optString("name") == name,
                                    imagePath = cleanImage(m.optString("image"))
                                ))
                            }

                            main.post {
                                listener?.onConnected(name, online)
                                list.forEach { listener?.onMessage(it) }
                            }
                        }
                        "online" -> {
                            val online = o.optInt("online", 1)
                            val usersArr = o.optJSONArray("users") ?: JSONArray()
                            val users = mutableListOf<String>()
                            for (i in 0 until usersArr.length()) {
                                users.add(usersArr.optString(i))
                            }
                            main.post { listener?.onOnline(online, users) }
                        }
                        "chat" -> {
                            val msg = Message(
                                name = o.optString("name"),
                                text = o.optString("text"),
                                time = o.optLong("time"),
                                self = o.optString("name") == myName && myName.isNotEmpty(),
                                imagePath = cleanImage(o.optString("image"))
                            )
                            main.post { listener?.onMessage(msg) }
                        }
                        else -> { /* 忽略未知类型 */ }
                    }
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                connecting = false
                ws = null
                val reason = when {
                    response != null -> "服务器无响应（${response.code}）"
                    t is java.net.UnknownHostException -> "无法解析服务器地址"
                    t is java.net.SocketTimeoutException -> "连接超时"
                    t is java.net.ConnectException -> "网络不可达"
                    else -> t.message ?: "未知错误"
                }
                main.post { listener?.onDisconnected(reason) }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                connecting = false
                ws = null
                main.post { listener?.onDisconnected("连接已断开") }
            }
        })
    }

    private fun cleanImage(s: String): String? =
        if (s.isBlank() || s == "null") null else s

    fun send(text: String, imagePath: String? = null): Boolean {
        val w = ws ?: return false
        val body = JSONObject().apply {
            put("type", "chat")
            put("text", text)
            if (!imagePath.isNullOrBlank()) put("image", imagePath)
        }.toString()
        return w.send(body)
    }

    /**
     * 上传图片。bytes 为压缩后的图片数据，mimeType 如 "image/jpeg"。
     * 回调在主线程。
     */
    fun uploadImage(bytes: ByteArray, mimeType: String, cb: UploadCallback) {
        Thread {
            try {
                val body = bytes.toRequestBody(mimeType.toMediaTypeOrNull())
                val req = Request.Builder().url(UPLOAD_URL).post(body).build()
                http.newCall(req).execute().use { resp ->
                    val text = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        val err = runCatching { JSONObject(text).optString("error") }
                            .getOrDefault("")
                        main.post { cb.onFailed(err.ifBlank { "上传失败（${resp.code}）" }) }
                        return@use
                    }
                    val path = runCatching { JSONObject(text).optString("path") }
                        .getOrDefault("")
                    main.post {
                        if (path.isBlank()) cb.onFailed("服务器返回异常")
                        else cb.onSuccess(path)
                    }
                }
            } catch (e: Exception) {
                main.post { cb.onFailed(e.message ?: "上传出错") }
            }
        }.start()
    }

    fun disconnect() {
        runCatching { ws?.close(1000, "bye") }
        ws = null
        connecting = false
    }
}
