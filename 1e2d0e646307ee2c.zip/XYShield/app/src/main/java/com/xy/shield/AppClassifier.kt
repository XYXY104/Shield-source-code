package com.xy.shield

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

/**
 * 统一的「系统应用」判定。
 *
 * 判定顺序（任一命中即视为系统应用）：
 *  1. FLAG_SYSTEM / FLAG_UPDATED_SYSTEM_APP —— 官方标志
 *  2. UID < 10000 —— Android 普通应用 UID 从 10000 起，以下都是系统服务
 *  3. sourceDir 落在系统分区（/system、/system_ext、/vendor、/product、/apex、/odm、/oem）
 *  4. 预装但被用户更新过（有 FLAG_SYSTEM 被清掉的情况，靠 installLocation + 无删除能力补判）
 *  5. 关键系统包名兜底（部分定制 ROM 把设置、桌面做成非 FLAG_SYSTEM）
 */
object AppClassifier {

    private val SYSTEM_PREFIXES = listOf(
        "/system",
        "/system_ext",
        "/vendor",
        "/product",
        "/apex",
        "/odm",
        "/oem"
    )

    /**
     * 关键系统包名兜底。
     * 部分定制 ROM（尤其国产系统）会把设置、拨号、桌面、文件管理做成
     * 不带 FLAG_SYSTEM 的普通包，必须靠包名前缀识别。
     */
    private val SYSTEM_PKG_PREFIXES = listOf(
        "android",
        "com.android.systemui",
        "com.android.settings",
        "com.android.phone",
        "com.android.providers.",
        "com.android.server.",
        "com.android.launcher",
        "com.android.inputmethod",
        "com.android.packageinstaller",
        "com.android.permissioncontroller",
        "com.android.shell",
        "com.android.bluetooth",
        "com.android.nfc",
        "com.android.providers.telephony",
        "com.google.android.gms",
        "com.google.android.gsf",
        "com.miui.",
        "com.xiaomi.",
        "com.huawei.",
        "com.hihonor.",
        "com.oppo.",
        "com.coloros.",
        "com.oplus.",
        "com.oneplus.",
        "com.vivo.",
        "com.bbk.",
        "com.meizu.",
        "com.samsung.",
        "com.sec.android."
    )

    fun isSystemApp(ctx: Context, pkg: String?): Boolean {
        if (pkg.isNullOrEmpty()) return false
        // 优先包名兜底，避免包信息拿不到时误判为普通应用
        if (isSystemPkgName(pkg)) return true
        val ai = try {
            ctx.packageManager.getApplicationInfo(pkg, 0)
        } catch (e: Exception) {
            return false
        }
        return isSystemApp(ctx, ai)
    }

    private fun isSystemPkgName(pkg: String): Boolean =
        SYSTEM_PKG_PREFIXES.any { pkg == it || pkg.startsWith(it) }

    fun isSystemApp(ctx: Context, ai: ApplicationInfo): Boolean {
        if (isSystemPkgName(ai.packageName)) return true

        if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) return true
        if ((ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) return true

        // 系统服务 UID
        if (ai.uid in 1000 until 10000) return true

        // 系统分区路径
        val src = ai.sourceDir
        if (src != null && SYSTEM_PREFIXES.any { src.startsWith(it) }) return true

        return false
    }

    /** 用户可管理的普通应用：非系统 + 有启动入口 */
    fun isManagedApp(ctx: Context, ai: ApplicationInfo): Boolean {
        if (isSystemApp(ctx, ai)) return false
        return try {
            ctx.packageManager.getLaunchIntentForPackage(ai.packageName) != null
        } catch (e: Exception) {
            false
        }
    }

    /** 取全部可管理应用（非系统、有启动入口、排除自身） */
    fun installedManagedApps(ctx: Context): List<ApplicationInfo> {
        val pm = ctx.packageManager
        val apps: List<ApplicationInfo> =
            if (android.os.Build.VERSION.SDK_INT >= 33)
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            else @Suppress("DEPRECATION") pm.getInstalledApplications(0)

        return apps.filter {
            it.packageName != ctx.packageName && isManagedApp(ctx, it)
        }
    }
}
