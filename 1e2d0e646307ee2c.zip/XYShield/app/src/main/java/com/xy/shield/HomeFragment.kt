package com.xy.shield

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment

class HomeFragment : Fragment() {

    private lateinit var btnA11y: TextView
    private lateinit var btnOverlay: TextView
    private lateinit var btnShizuku: TextView
    private lateinit var subShizuku: TextView
    private lateinit var subA11y: TextView
    private lateinit var subOverlay: TextView
    private lateinit var dotA11y: View
    private lateinit var dotOverlay: View
    private lateinit var dotShizuku: View
    private lateinit var btnUsage: TextView
    private lateinit var subUsage: TextView
    private lateinit var dotUsage: View
    private lateinit var btnToggle: TextView
    private lateinit var tvHint: TextView

    private val GREEN = Color.parseColor("#4FC76A")
    private val ORANGE = Color.parseColor("#E8A33D")
    private val RED = Color.parseColor("#DE4A4A")
    private val GREY = Color.parseColor("#C9C7B8")

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_home, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        btnA11y = v.findViewById(R.id.btnA11y)
        btnOverlay = v.findViewById(R.id.btnOverlay)
        btnShizuku = v.findViewById(R.id.btnShizuku)
        subA11y = v.findViewById(R.id.subA11y)
        subOverlay = v.findViewById(R.id.subOverlay)
        subShizuku = v.findViewById(R.id.subShizuku)
        dotA11y = v.findViewById(R.id.dotA11y)
        dotOverlay = v.findViewById(R.id.dotOverlay)
        dotShizuku = v.findViewById(R.id.dotShizuku)
        btnUsage = v.findViewById(R.id.btnUsage)
        subUsage = v.findViewById(R.id.subUsage)
        dotUsage = v.findViewById(R.id.dotUsage)
        btnToggle = v.findViewById(R.id.btnToggle)
        tvHint = v.findViewById(R.id.tvHint)

        v.findViewById<LinearLayout>(R.id.rowA11y).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        v.findViewById<LinearLayout>(R.id.rowOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${requireContext().packageName}")))
        }
        v.findViewById<LinearLayout>(R.id.rowShizuku).setOnClickListener {
            val ctx = requireContext()
            if (ShizukuHelper.checkInstalled(ctx)) {
                // 装了就直接打开 Shizuku 应用本身（已激活时也一样，方便查看/改授权）
                if (!ShizukuHelper.openShizuku(ctx)) {
                    // 极端情况下没入口，退回设置页
                    ShizukuHelper.requestPermission(ctx)
                }
            } else {
                // 没装才去下载
                ShizukuHelper.openDownloadPage(ctx)
            }
            refresh()
        }
        // 使用情况访问权限：用于精准识别前台应用
        v.findViewById<LinearLayout>(R.id.rowUsage).setOnClickListener {
            if (!UsageAccess.hasPermission(requireContext())) {
                UsageAccess.openSettings(requireContext())
            } else {
                android.widget.Toast.makeText(requireContext(),
                    "已授权 · 前台应用识别已启用",
                    android.widget.Toast.LENGTH_SHORT).show()
            }
        }

        btnToggle.setOnClickListener { (activity as MainActivity).toggleGuard() }

        // 公告卡片
        v.findViewById<LinearLayout>(R.id.cardNotice).setOnClickListener {
            showNoticeDialog()
        }

        // 拆解应用
        v.findViewById<View>(R.id.cardUnpack).setOnClickListener {
            UnpackActivity.start(requireContext())
        }

        // 隐藏的管理员入口：顶部任意位置快速连点 10 次
        v.findViewById<View>(R.id.hotAdmin).setOnClickListener {
            val now = System.currentTimeMillis()
            // 相邻两次点击超过 400ms 视为重新计数，避免误触累积
            if (now - lastAdminTap > 400L) adminTapCount = 0
            lastAdminTap = now
            adminTapCount++

            if (adminTapCount >= ADMIN_TAPS) {
                adminTapCount = 0
                lastAdminTap = 0L
                hotAdminHandler.removeCallbacks(hotAdminReset)
                showAdminPasswordDialog()
            } else {
                hotAdminHandler.removeCallbacks(hotAdminReset)
                hotAdminHandler.postDelayed(hotAdminReset, 1200L)
            }
        }
    }

    private var adminTapCount = 0
    private var lastAdminTap = 0L
    private val hotAdminHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val hotAdminReset = Runnable {
        adminTapCount = 0
        lastAdminTap = 0L
    }

    /** 管理员密码验证弹窗：只能点右上角叉关闭 */
    private fun showAdminPasswordDialog() {
        val ctx = requireContext()
        val d = android.app.Dialog(ctx)
        d.setContentView(R.layout.dialog_admin_pwd)

        // 点外部不关闭
        d.setCanceledOnTouchOutside(false)
        // 返回键也不关闭
        d.setCancelable(false)
        d.setOnKeyListener { _, keyCode, _ ->
            keyCode == android.view.KeyEvent.KEYCODE_BACK
        }

        d.window?.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        d.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.82).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT)

        val et = d.findViewById<android.widget.EditText>(R.id.etPassword)
        val tvError = d.findViewById<TextView>(R.id.tvError)

        // 唯一的关闭方式
        d.findViewById<View>(R.id.btnClosePwd).setOnClickListener { d.dismiss() }

        fun verify() {
            val input = et.text.toString()
            if (input == ADMIN_PASSWORD) {
                d.dismiss()
                AdminActivity.start(ctx)
            } else {
                tvError.visibility = View.VISIBLE
                et.setText("")
                et.requestFocus()
                val shake = android.view.animation.TranslateAnimation(
                    -10f, 10f, 0f, 0f).apply {
                    duration = 60
                    repeatCount = 4
                }
                d.findViewById<View>(R.id.etPassword).startAnimation(shake)
            }
        }

        d.findViewById<View>(R.id.btnConfirmPwd).setOnClickListener { verify() }

        et.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                verify(); true
            } else false
        }

        d.show()
        et.requestFocus()
    }

    override fun onResume() { super.onResume(); refresh() }

    fun refresh() {
        val ctx = context ?: return

        // 无障碍
        val a11y = ShieldAccessibilityService.isRunning
        setRow(dotA11y, btnA11y, subA11y, a11y,
            "用于识别当前运行的恶意应用", "已开启")

        // 悬浮窗
        val ov = Settings.canDrawOverlays(ctx)
        setRow(dotOverlay, btnOverlay, subOverlay, ov,
            "用于显示桌面守护球与拦截弹窗", "已开启")

        // Shizuku
        val sz = ShizukuHelper.checkGranted()
        val installed = ShizukuHelper.checkInstalled(ctx)
        when {
            sz -> {
                dotShizuku.background = circle(GREEN)
                subShizuku.text = "已连接 · 可强力卸载"
                subShizuku.setTextColor(GREEN)
                chip(btnShizuku, "已连接", GREEN)
            }
            installed -> {
                dotShizuku.background = circle(ORANGE)
                subShizuku.text = "已安装 · 点击启动并授权"
                subShizuku.setTextColor(ORANGE)
                chip(btnShizuku, "去授权", ORANGE)
            }
            else -> {
                dotShizuku.background = circle(RED)
                subShizuku.text = "未检测到 Shizuku"
                subShizuku.setTextColor(RED)
                chip(btnShizuku, "去安装", RED)
            }
        }

        // 使用情况访问
        val hasUsage = UsageAccess.hasPermission(ctx)
        setRow(dotUsage, btnUsage, subUsage, hasUsage,
            "用于精准识别前台应用", "已授权 · 识别更准")

        refreshToggle()
        refreshNotice()
    }

    /** 主页公告卡片：显示最新公告预览 */
    private fun refreshNotice() {
        val v = view ?: return
        val ctx = context ?: return
        val n = NoticeStore.load(ctx)
        val preview = v.findViewById<TextView>(R.id.tvNoticePreview) ?: return
        preview.text = if (n.isEmpty) "无公告"
        else n.content.replace("\n", " ").take(40).let {
            if (n.content.length > 40) "$it…" else it
        }
    }

    fun refreshToggle() {
        val on = (activity as MainActivity).guardOn
        if (on) {
            btnToggle.text = "关闭守护"
            btnToggle.setBackgroundResource(R.drawable.bg_btn_grey)
            tvHint.text = "守护运行中 · 通知栏常驻\n划掉应用也不会停止"
        } else {
            btnToggle.text = "开启守护"
            btnToggle.setBackgroundResource(R.drawable.bg_btn_red)
            tvHint.text = "开启后通知栏常驻守护状态\n划掉应用也不会停止"
        }
    }

    /** 公告弹窗：读取管理员发布的公告 */
    private fun showNoticeDialog() {
        val ctx = requireContext()
        val n = NoticeStore.load(ctx)

        val d = android.app.Dialog(ctx)
        d.setContentView(R.layout.dialog_notice)
        d.window?.setBackgroundDrawable(
            android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
        d.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.84).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT)

        val tvContent = d.findViewById<TextView>(R.id.tvNoticeContent)
        val tvTitle = d.findViewById<TextView>(R.id.tvNoticeTitle)
        val tvMeta = d.findViewById<TextView>(R.id.tvNoticeMeta)

        if (n.isEmpty) {
            tvTitle.text = "公告"
            tvMeta.visibility = View.GONE
            tvContent.text = "暂无公告"
        } else {
            tvTitle.text = n.title.ifBlank { "公告" }
            tvContent.text = n.content
            if (n.version.isNotBlank() || n.time.isNotBlank()) {
                tvMeta.visibility = View.VISIBLE
                tvMeta.text = buildString {
                    if (n.version.isNotBlank()) append("版本 ${n.version}")
                    if (n.version.isNotBlank() && n.time.isNotBlank()) append(" · ")
                    if (n.time.isNotBlank()) append(n.time)
                }
            } else {
                tvMeta.visibility = View.GONE
            }
        }

        d.findViewById<TextView>(R.id.btnNoticeClose).setOnClickListener { d.dismiss() }
        d.show()
    }

    companion object {
        /** 管理员入口需要快速连点的次数 */
        private const val ADMIN_TAPS = 10
        /** 管理员密码 */
        private const val ADMIN_PASSWORD = "XY Hub"
    }

    private fun setRow(dot: View, btn: TextView, sub: TextView,
                       on: Boolean, offDesc: String, onDesc: String) {
        if (on) {
            dot.background = circle(GREEN)
            sub.text = onDesc
            sub.setTextColor(GREEN)
            chip(btn, "已开启", GREEN)
        } else {
            dot.background = circle(GREY)
            sub.text = offDesc
            sub.setTextColor(Color.parseColor("#A7A594"))
            chip(btn, "去授权", GREY)
        }
    }

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    /** 胶囊按钮：浅色底 + 彩色字 */
    private fun chip(tv: TextView, text: String, color: Int) {
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.background = GradientDrawable().apply {
            cornerRadius = 60f * resources.displayMetrics.density
            setColor(color)
        }
    }
}
