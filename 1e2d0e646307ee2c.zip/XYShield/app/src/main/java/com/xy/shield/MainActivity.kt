package com.xy.shield

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.xy.shield.widget.LiquidNavBar

class MainActivity : AppCompatActivity() {

    var guardOn: Boolean = false
        private set

    private lateinit var nav: LiquidNavBar
    private var homeFragment: HomeFragment? = null
    private var recordsFragment: RecordsFragment? = null
    private var chatFragment: ChatFragment? = null
    private var settingsFragment: SettingsFragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        guardOn = getSharedPreferences("xy", MODE_PRIVATE).getBoolean("guard_on", false)

        nav = findViewById(R.id.liquidNav)
        nav.labels = arrayOf("主页", "记录", "聊天", "设置")
        nav.onTabSelected = { idx -> switchTo(idx) }
        switchTo(0)

        // 摇一摇 → 紧急拦截弹窗
        ShakeDetector.start(this) {
            if (Settings.canDrawOverlays(this))
                startService(Intent(this, OverlayService::class.java))
        }
    }

    private fun switchTo(index: Int) {
        val f: Fragment = when (index) {
            0 -> {
                if (homeFragment == null) homeFragment = HomeFragment()
                homeFragment!!
            }
            1 -> {
                if (recordsFragment == null) recordsFragment = RecordsFragment()
                recordsFragment!!
            }
            2 -> {
                if (chatFragment == null) chatFragment = ChatFragment()
                chatFragment!!
            }
            else -> {
                if (settingsFragment == null) settingsFragment = SettingsFragment()
                settingsFragment!!
            }
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, f)
            .commitAllowingStateLoss()
    }

    fun toggleGuard() {
        if (guardOn) {
            stopService(Intent(this, GuardService::class.java))
            stopService(Intent(this, BubbleService::class.java))
            getSharedPreferences("xy", MODE_PRIVATE).edit()
                .putBoolean("guard_on", false).apply()
            guardOn = false
        } else {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
                return
            }
            requestIgnoreBatteryOptimization()
            startForegroundService(Intent(this, GuardService::class.java))
            startService(Intent(this, BubbleService::class.java))
            getSharedPreferences("xy", MODE_PRIVATE).edit()
                .putBoolean("guard_on", true).apply()
            guardOn = true
        }
        homeFragment?.refreshToggle()
    }

    @SuppressLint("BatteryLife")
    private fun requestIgnoreBatteryOptimization() {
        try {
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")))
            }
        } catch (e: Exception) {
            runCatching {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ShakeDetector.stop()
    }
}
