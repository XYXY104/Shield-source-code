package com.xy.shield

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial

/**
 * 白名单页面：
 * 列出全部非系统应用，每个应用一张小卡片 + 一个开关。
 * 开关打开 = 不拦截；关闭 = 拦截。
 */
class WhitelistActivity : AppCompatActivity() {

    private lateinit var llApps: LinearLayout
    private lateinit var etSearch: EditText
    private lateinit var tvCount: TextView
    private var all: List<WhitelistStore.AppEntry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_whitelist)

        llApps = findViewById(R.id.llApps)
        etSearch = findViewById(R.id.etSearch)
        tvCount = findViewById(R.id.tvCount)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { render(s?.toString().orEmpty()) }
        })

        loadApps()
    }

    private fun loadApps() {
        Thread {
            val list = WhitelistStore.loadApps(this)
            runOnUiThread {
                all = list
                render("")
            }
        }.start()
    }

    private fun render(keyword: String) {
        llApps.removeAllViews()
        val shown = if (keyword.isBlank()) all
        else all.filter {
            it.label.contains(keyword, true) || it.pkg.contains(keyword, true)
        }

        val allowedCount = all.count { it.allowed }
        tvCount.text = "共 ${all.size} 个应用 · 白名单 ${allowedCount} 个（系统应用已排除）"

        val inflater = LayoutInflater.from(this)
        shown.forEach { entry ->
            val row = inflater.inflate(R.layout.item_app, llApps, false)
            row.findViewById<TextView>(R.id.tvName).text = entry.label
            row.findViewById<TextView>(R.id.tvPkg).text = entry.pkg

            val icon = row.findViewById<ImageView>(R.id.ivIcon)
            runCatching {
                icon.setImageDrawable(packageManager.getApplicationIcon(entry.pkg))
            }.onFailure {
                icon.setImageResource(android.R.drawable.sym_def_app_icon)
            }

            val sw = row.findViewById<SwitchMaterial>(R.id.swAllow)
            sw.setOnCheckedChangeListener(null)
            sw.isChecked = entry.allowed
            sw.setOnCheckedChangeListener { _, checked ->
                WhitelistStore.setAllowed(this, entry.pkg, checked)
                // 更新内存状态
                all = all.map {
                    if (it.pkg == entry.pkg) it.copy(allowed = checked) else it
                }
                val cnt = all.count { it.allowed }
                tvCount.text = "共 ${all.size} 个应用 · 白名单 $cnt 个（系统应用已排除）"
            }

            // 点击整行也能切换
            row.setOnClickListener { sw.isChecked = !sw.isChecked }

            llApps.addView(row)
        }

        if (shown.isEmpty()) {
            val tv = TextView(this)
            tv.text = if (all.isEmpty()) "没有可添加的应用" else "没有匹配的应用"
            tv.setTextColor(0xFFB8B6A5.toInt())
            tv.textSize = 13f
            tv.gravity = android.view.Gravity.CENTER
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = 70
            llApps.addView(tv, lp)
        }
    }

    companion object {
        fun start(ctx: android.content.Context) {
            ctx.startActivity(Intent(ctx, WhitelistActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
