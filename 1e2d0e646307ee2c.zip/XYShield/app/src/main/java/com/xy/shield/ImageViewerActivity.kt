package com.xy.shield

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import java.io.File
import java.text.DecimalFormat

/**
 * 全屏图片查看器：左右滑动浏览，显示图片路径、尺寸、可疑原因。
 */
class ImageViewerActivity : AppCompatActivity() {

    companion object {
        private var images: List<ApkScanner.ScannedImage> = emptyList()

        fun open(ctx: android.content.Context, list: List<ApkScanner.ScannedImage>, index: Int) {
            images = list
            ctx.startActivity(Intent(ctx, ImageViewerActivity::class.java)
                .putExtra("index", index)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private lateinit var tvIndex: TextView
    private lateinit var tvName: TextView
    private lateinit var tvMeta: TextView
    private lateinit var tvWarn: TextView

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_viewer)

        val vp = findViewById<ViewPager>(R.id.vpImageViewer)
        tvIndex = findViewById(R.id.tvViewerIndex)
        tvName = findViewById(R.id.tvViewerName)
        tvMeta = findViewById(R.id.tvViewerMeta)
        tvWarn = findViewById(R.id.tvViewerWarn)

        findViewById<View>(R.id.btnViewerClose).setOnClickListener { finish() }

        vp.adapter = ViewerAdapter()
        val start = intent.getIntExtra("index", 0).coerceIn(0, (images.size - 1).coerceAtLeast(0))
        vp.currentItem = start
        bind(start)

        vp.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(position: Int) = bind(position)
        })

        // 下滑关闭
        var downY = 0f
        var downTime = 0L
        vp.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = ev.y
                    downTime = System.currentTimeMillis()
                }
                MotionEvent.ACTION_UP -> {
                    val dy = ev.y - downY
                    val dt = System.currentTimeMillis() - downTime
                    if (dy > 140 && dt < 420) {
                        finish()
                    }
                }
            }
            false
        }
    }

    private fun bind(index: Int) {
        val img = images.getOrNull(index) ?: return
        tvIndex.text = "${index + 1} / ${images.size}"
        tvName.text = img.entryName.substringAfterLast('/')

        val df = DecimalFormat("0.0")
        val sizeText = if (img.sizeBytes < 1024 * 1024)
            "${df.format(img.sizeBytes / 1024.0)} KB"
        else "${df.format(img.sizeBytes / 1024.0 / 1024.0)} MB"

        tvMeta.text = "${img.width} × ${img.height} · $sizeText\n${img.entryName}"

        if (img.horror) {
            tvWarn.visibility = View.VISIBLE
            tvWarn.text = "可疑图片 · ${img.horrorReason}"
        } else {
            tvWarn.visibility = View.GONE
        }
    }

    inner class ViewerAdapter : PagerAdapter() {
        override fun getCount(): Int = images.size
        override fun isViewFromObject(v: View, o: Any): Boolean = v === o

        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            val iv = ImageView(this@ImageViewerActivity).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(0xFF0A0A0C.toInt())
                contentDescription = "拆包图片"
            }
            container.addView(iv)

            // 后台解码全图（限制最大边长，避免 OOM）
            Thread {
                val bmp = decodeSampled(images[position].file, 1600)
                runOnUiThread { if (bmp != null) iv.setImageBitmap(bmp) }
            }.start()

            return iv
        }

        override fun destroyItem(container: ViewGroup, position: Int, obj: Any) {
            container.removeView(obj as View)
        }
    }

    private fun decodeSampled(file: File, targetMax: Int): Bitmap? = runCatching {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        var scale = 1
        val maxDim = maxOf(opts.outWidth, opts.outHeight)
        while (maxDim / scale > targetMax) scale *= 2
        val opts2 = BitmapFactory.Options().apply { inSampleSize = scale }
        BitmapFactory.decodeFile(file.absolutePath, opts2)
    }.getOrNull()
}
