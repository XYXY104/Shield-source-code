package com.xy.shield

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

class RecordsFragment : Fragment() {

    private var list: LinearLayout? = null
    private var empty: View? = null
    private var tvTotal: TextView? = null
    private var tvBlocked: TextView? = null

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.fragment_records, c, false)

    override fun onViewCreated(v: View, s: Bundle?) {
        list = v.findViewById(R.id.llRecordList)
        empty = v.findViewById(R.id.llEmpty)
        tvTotal = v.findViewById(R.id.tvTotal)
        tvBlocked = v.findViewById(R.id.tvBlocked)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val ctx = context ?: return
        val ll = list ?: return
        ll.removeAllViews()

        val all = RecordsStore.load(ctx)
        tvTotal?.text = all.size.toString()
        tvBlocked?.text = all.count { it.action.contains("拦截") || it.action.contains("卸载") }
            .toString()

        val recs = all.take(60)
        empty?.visibility = if (recs.isEmpty()) View.VISIBLE else View.GONE

        val inflater = LayoutInflater.from(ctx)
        recs.forEach { r ->
            val row = inflater.inflate(R.layout.item_record, ll, false)
            val pkg = r.pkg
            val isBlock = r.action.contains("拦截") || r.action.contains("卸载")

            row.findViewById<TextView>(R.id.tvPkg).text = labelOf(pkg)
            row.findViewById<TextView>(R.id.tvAction).text = r.action
            row.findViewById<TextView>(R.id.tvTime).text = r.time

            val icon = row.findViewById<ImageView>(R.id.ivIcon)
            val fl = row.findViewById<View>(R.id.flIcon)
            val tag = row.findViewById<TextView>(R.id.tvTag)

            if (isBlock) {
                fl.setBackgroundResource(R.drawable.bg_icon_red)
                icon.setImageResource(R.drawable.ic_block)
                icon.setColorFilter(ContextCompat.getColor(ctx, R.color.xy_red))
                tag.text = "已拦截"
                tag.setTextColor(ContextCompat.getColor(ctx, R.color.xy_red))
                tag.setBackgroundResource(R.drawable.bg_tag_red)
            } else {
                fl.setBackgroundResource(R.drawable.bg_icon_blue)
                icon.setImageResource(R.drawable.ic_info_small)
                icon.setColorFilter(ContextCompat.getColor(ctx, R.color.xy_blue))
                tag.text = "已记录"
                tag.setTextColor(ContextCompat.getColor(ctx, R.color.xy_text_sub))
                tag.setBackgroundResource(R.drawable.bg_tag_grey)
            }
            ll.addView(row)
        }
    }

    /** 尽量把包名换成应用名，找不到就退回包名 */
    private fun labelOf(pkg: String): String {
        val ctx = context ?: return pkg
        return try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }
}
