package com.xy.shield

import android.content.Context

/**
 * 公告存储。
 *
 * 管理员在「管理员页面」发布公告 / 更新公告后写入这里，
 * 主页公告卡片读到就展示。用 SharedPreferences 保证重启后仍然存在。
 */
object NoticeStore {

    private const val SP = "notice"

    data class Notice(
        val title: String,
        val content: String,
        val version: String,
        val time: String,
        val important: Boolean
    ) {
        val isEmpty: Boolean get() = content.isBlank()
    }

    fun load(ctx: Context): Notice {
        val sp = ctx.getSharedPreferences(SP, Context.MODE_PRIVATE)
        return Notice(
            title = sp.getString("title", "公告").orEmpty(),
            content = sp.getString("content", "").orEmpty(),
            version = sp.getString("version", "").orEmpty(),
            time = sp.getString("time", "").orEmpty(),
            important = sp.getBoolean("important", false)
        )
    }

    fun save(ctx: Context, n: Notice) {
        ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).edit().apply {
            putString("title", n.title)
            putString("content", n.content)
            putString("version", n.version)
            putString("time", n.time)
            putBoolean("important", n.important)
        }.apply()
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).edit().clear().apply()
    }

    /** 公告是否有内容 */
    fun hasNotice(ctx: Context): Boolean = !load(ctx).isEmpty
}
