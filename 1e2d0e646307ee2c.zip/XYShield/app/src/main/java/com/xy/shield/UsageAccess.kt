package com.xy.shield

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process

/**
 * 使用情况访问权限（PACKAGE_USAGE_STATS）。
 * 授予后可以用 UsageStatsManager 实时查前台应用，摇一摇识别更准。
 */
object UsageAccess {

    fun hasPermission(ctx: Context): Boolean {
        return try {
            val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), ctx.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), ctx.packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    fun openSettings(ctx: Context) {
        val intents = listOf(
            Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            Intent(android.provider.Settings.ACTION_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        for (i in intents) {
            if (runCatching { ctx.startActivity(i); true }.getOrDefault(false)) return
        }
        android.widget.Toast.makeText(ctx, "请到系统设置 → 应用 → 特殊权限 中授予使用情况访问",
            android.widget.Toast.LENGTH_LONG).show()
    }
}
