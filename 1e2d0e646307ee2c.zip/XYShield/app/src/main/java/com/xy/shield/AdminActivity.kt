package com.xy.shield

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 管理员控制台（隐藏入口：主页顶部右上角连点 10 次）
 *
 * 功能：
 *  - 编辑公告标题 / 正文 / 版本号 / 是否重要
 *  - 发布 → 写入 NoticeStore，主页公告卡片立即刷新
 *  - 清除 → 恢复「无公告」
 */
class AdminActivity : AppCompatActivity() {

    private lateinit var etTitle: EditText
    private lateinit var etContent: EditText
    private lateinit var etVersion: EditText
    private lateinit var swImportant: SwitchMaterial
    private lateinit var tvCurrentTitle: TextView
    private lateinit var tvCurrentMeta: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        etTitle = findViewById(R.id.etTitle)
        etContent = findViewById(R.id.etContent)
        etVersion = findViewById(R.id.etVersion)
        swImportant = findViewById(R.id.swImportant)
        tvCurrentTitle = findViewById(R.id.tvCurrentTitle)
        tvCurrentMeta = findViewById(R.id.tvCurrentMeta)

        findViewById<ImageView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnPublish).setOnClickListener { publish() }
        findViewById<View>(R.id.btnClear).setOnClickListener { clear() }

        fillExisting()
    }

    /** 把已发布的公告回填到表单 */
    private fun fillExisting() {
        val n = NoticeStore.load(this)
        if (n.isEmpty) {
            tvCurrentTitle.text = "暂无公告"
            tvCurrentMeta.text = "尚未发布"
        } else {
            tvCurrentTitle.text = n.title.ifBlank { "公告" }
            tvCurrentMeta.text = buildString {
                if (n.version.isNotBlank()) append("版本 ${n.version} · ")
                append(n.time)
                if (n.important) append(" · 重要")
            }
            etTitle.setText(n.title)
            etContent.setText(n.content)
            etVersion.setText(n.version)
            swImportant.isChecked = n.important
        }
    }

    private fun publish() {
        val content = etContent.text.toString().trim()
        if (content.isEmpty()) {
            toast("公告内容不能为空")
            etContent.requestFocus()
            return
        }

        val title = etTitle.text.toString().trim().ifBlank { "公告" }
        val version = etVersion.text.toString().trim()
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())

        NoticeStore.save(this, NoticeStore.Notice(
            title = title,
            content = content,
            version = version,
            time = time,
            important = swImportant.isChecked
        ))

        tvCurrentTitle.text = title
        tvCurrentMeta.text = buildString {
            if (version.isNotBlank()) append("版本 $version · ")
            append(time)
            if (swImportant.isChecked) append(" · 重要")
        }

        toast("公告已发布 · 全服推送完成")
    }

    private fun clear() {
        if (NoticeStore.hasNotice(this)) {
            NoticeStore.clear(this)
            etTitle.setText("")
            etContent.setText("")
            etVersion.setText("")
            swImportant.isChecked = false
            tvCurrentTitle.text = "暂无公告"
            tvCurrentMeta.text = "尚未发布"
            toast("公告已清除")
        } else {
            toast("当前没有公告")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        fun start(ctx: android.content.Context) {
            ctx.startActivity(Intent(ctx, AdminActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
