# XY护盾 · 安卓项目

## 打包 APK 步骤（必须本地做）

1. 电脑安装 [Android Studio](https://developer.android.com/studio)（含 JDK17）
2. 解压本 zip → 打开 Android Studio → `Open` 选择 `XYShield` 文件夹
3. 等右下角 Gradle Sync 完成（会自动下载依赖，包括 Shizuku）
4. 手机开「开发者选项 → USB调试」插电脑 → 点顶部绿色 ▶ Run
   （或菜单 Build → Build APKs，APK 在 `app/build/outputs/apk/debug/`）

## 功能对应

| 截图里的元素 | 实现位置 |
|---|---|
| 需授权无障碍（授权后按钮变绿） | `MainActivity` + `ShieldAccessibilityService` |
| 需授权悬浮窗（变绿） | `MainActivity` + `OverlayService` |
| ADB强力卸载（Shizuku）真实检测 | `ShizukuHelper`（Shizuku v13 官方 API，pingBinder + checkSelfPermission） |
| 开启防病毒守护（需三项全过才可开） | `MainActivity` 开关逻辑 |
| 前台应用强监测 | 无障碍服务实时上报前台包名 |
| 摇一摇弹白色卡片 | `ShakeDetector` → `OverlayService` |
| 卡片：检测运行中应用 / 自动卸载 / 手动卸载 | `OverlayService`（自动=Shizuku `pm uninstall`；手动=跳系统卸载页） |
| 阻拦记录 | `RecordsStore`（本地存储，主页底部展示） |

## 注意

- Shizuku 检测是**真的**：没装 Shizuku 显示红色「未检测到」；装了未授权显示黄色提示；授权成功变绿色
- 「自动卸载」只在 Shizuku 已授权时可用，否则请用「手动卸载」
- 外观（渐变背景、圆角卡片、蓝色按钮）已按截图还原，可继续微调 `res/drawable` 和 `res/values/styles.xml`
